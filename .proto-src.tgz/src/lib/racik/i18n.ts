export type Lang = "id" | "en";

/**
 * Interface copy only. Recipe content — titles, ingredient names, steps,
 * notes — stays in Bahasa Indonesia whichever language is chosen, because it
 * is data written by cooks, not chrome. Translating the recipes is a writing
 * project; this is the switch for everything around them.
 *
 * English is on (23 Okt 2026): every screen goes through t(), and
 * scripts/check-i18n.mjs fails the build if new interface text skips it.
 * Legal pages and route meta (SEO) stay Indonesian by decision.
 *
 * Indonesian is the source. English is the translation, never the reverse:
 * the app is for Indonesian home cooks and the Indonesian wording is the one
 * that gets argued over.
 */
const DICT = {
  // bottom tabs
  tab_home: ["Masak Apa", "Cook"],
  tab_search: ["Cari", "Search"],
  tab_plan: ["Rencana", "Plan"],
  tab_import: ["Tambah Resep", "Add recipe"],
  tab_write: ["Tulis resep", "Write"],
  tab_book: ["Koleksi", "Collection"],

  // home
  greeting_morning: ["Selamat pagi", "Good morning"],
  greeting_midday: ["Selamat siang", "Good afternoon"],
  greeting_evening: ["Selamat sore", "Good evening"],
  greeting_night: ["Selamat malam", "Good evening"],
  ask_breakfast: ["Sarapan apa hari ini?", "What's for breakfast?"],
  ask_lunch: ["Masak apa siang ini?", "What's for lunch?"],
  ask_dinner: ["Masak apa malam ini?", "What's for dinner?"],
  for_people: ["{n} orang", "{n} people"],
  search_placeholder: ["Cari resep atau bahan…", "Search recipes or ingredients…"],
  suggestions: ["Saran untukmu", "Suggested for you"],
  tampilan: ["Tampilan", "View"],
  tampilan_foto: ["Foto besar", "Large photos"],
  tampilan_baris: ["Baris", "List"],
  tampilan_grid: ["Grid", "Grid"],
  shuffle: ["Saran lain", "More ideas"],
  no_match: [
    "Belum ada resep yang cocok dengan pilihan ini.",
    "No recipes match these choices yet.",
  ],
  clear_filters: ["Hapus semua filter", "Clear all filters"],
  portions: ["porsi", "portions"],

  // filters
  filter_quick: ["≤ 30 menit", "30 min or less"],
  filter_easy: ["Gampang", "Easy"],
  filter_protein: ["Protein tinggi", "High protein"],
  filter_batch: ["Sekali masak banyak", "Cooks a lot at once"],
  filter_kids: ["Anak suka", "Kids like it"],

  // settings
  settings: ["Pengaturan", "Settings"],
  back: ["Kembali", "Back"],
  usual_portions: ["Porsi biasa", "Usual portions"],
  usual_portions_detail: [
    "Dipakai saat membuka resep pertama kali.",
    "Used when you first open a recipe.",
  ],
  measures: ["Satuan takaran", "Measurements"],
  measures_home: ["Rumah", "Kitchen"],
  measures_gram: ["Gram", "Grams"],
  text_size: ["Ukuran tulisan", "Text size"],
  text_normal: ["Normal", "Normal"],
  text_large: ["Besar", "Large"],
  text_largest: ["Paling besar", "Largest"],
  language: ["Bahasa", "Language"],
  hide_check: [
    "Sembunyikan resep yang perlu dicek atau tidak halal",
    "Hide recipes that need checking or aren't halal",
  ],
  hide_check_detail: [
    "Penyaring ini berdasarkan daftar bahan. Racik bukan lembaga sertifikasi halal.",
    "This filter reads the ingredient list. Racik is not a halal certification body.",
  ],
  about: ["Tentang Racik", "About Racik"],
  about_body: [
    "Racik berisi {n} resep yang tersimpan di perangkat. Takaran rumah dan perkiraan protein punya batas; baca catatan pada setiap resep.",
    "Racik holds {n} recipes stored on your device. Kitchen measures and protein estimates have limits — read the note on each recipe.",
  ],
  erase_all: ["Hapus semua data", "Erase all data"],

  // account
  sign_in: ["Masuk", "Sign in"],
  sign_out: ["Keluar", "Sign out"],
  sign_in_title: ["Masuk ke Racik", "Sign in to Racik"],
  sign_in_why: [
    "Kamu hanya perlu masuk kalau mau menulis resep sendiri. Memasak, menyimpan Favorit, dan menambah resep dari luar tetap bisa tanpa akun.",
    "You only need an account to write your own recipes. Cooking, saving and importing from videos all work without one.",
  ],
  continue_google: ["Lanjut dengan Google", "Continue with Google"],
  email_label: ["Alamat email", "Email address"],
  continue_: ["Lanjut", "Next"],
  code_title: ["Masukkan kodenya", "Enter the code"],
  code_sent_to: ["Kami kirim enam angka ke {email}.", "We sent six digits to {email}."],
  code_resend: ["Kirim ulang kodenya", "Send the code again"],
  profile_title: ["Kenalan dulu", "Let's meet"],
  profile_why: [
    "Nama ini yang muncul di resep yang kamu tulis. Fotonya boleh dilewati.",
    "This name appears on the recipes you write. The photo is optional.",
  ],
  add_photo: ["Tambah foto", "Add a photo"],
  skip: ["Lewati", "Skip"],
  done: ["Selesai", "Done"],
  send_link: ["Kirim tautan masuk", "Send sign-in link"],
  link_sent: [
    "Tautannya sudah dikirim. Buka emailmu, lalu ketuk tautannya untuk masuk.",
    "The link is on its way. Open your email and tap it to sign in.",
  ],
  or: ["atau", "or"],
  your_name: ["Namamu", "Your name"],
  your_name_detail: [
    "Nama ini yang muncul di resep yang kamu tulis.",
    "This name appears on the recipes you write.",
  ],
  save: ["Simpan", "Save"],
  signed_in_as: ["Masuk sebagai {name}", "Signed in as {name}"],
  not_connected: ["Racik belum tersambung ke server.", "Racik is not connected to the server."],

  // the sign-in offer — shown once, always skippable
  offer_title: ["Simpan resepmu, bagikan masakanmu", "Keep your recipes, share your cooking"],
  offer_write: [
    "Menulis resepmu sendiri, lengkap dengan takaran yang ikut jumlah porsi.",
    "Write your own recipes, with measurements that follow the portion count.",
  ],
  offer_share: [
    "Membagikannya ke teman lewat WhatsApp — mereka bisa membukanya tanpa memasang Racik.",
    "Share them on WhatsApp — friends can open them without installing Racik.",
  ],
  offer_seen: ["Melihat berapa orang memasak resepmu.", "See how many people cooked your recipe."],
  offer_not_needed: [
    "Tanpa akun pun {n} resep, takaran, dan mode masak tetap jalan — termasuk tanpa sinyal.",
    "Without an account you still get all {n} recipes, the measurements and cook mode — signal or no signal.",
  ],
  offer_later: ["Nanti saja", "Maybe later"],
  // import progress, redesigned 29 Okt 2026
  prog_first_link: ["Membaca video", "Reading the video"],
  prog_first_suara: ["Mendengarkan video", "Listening to the video"],
  prog_first_teks: ["Membaca teks", "Reading the text"],
  prog_first_foto: ["Membaca foto", "Reading the photo"],
  prog_bahan: ["Mengenali bahan", "Recognising ingredients"],
  prog_langkah: ["Menyusun langkah", "Writing the steps"],
  prog_rapikan: ["Merapikan resep", "Tidying up the recipe"],
  prog_head_link: ["Membaca videonya", "Reading the video"],
  prog_head_suara: ["Mendengarkan videonya", "Listening to the video"],
  prog_head_teks: ["Membaca teksnya", "Reading the text"],
  prog_head_foto: ["Membaca fotonya", "Reading the photo"],
  prog_head_bahan: ["Mengenali bahan", "Recognising ingredients"],
  prog_head_langkah: ["Menyusun langkah memasak", "Writing the cooking steps"],
  prog_head_rapikan: ["Merapikan resep", "Tidying up the recipe"],
  prog_det_link: [
    "Memutar video dan membaca keterangannya…",
    "Playing the video and reading its caption…",
  ],
  prog_det_suara: [
    "Mendengarkan suara di videonya, ini yang paling lama…",
    "Listening to the video's sound, this takes longest…",
  ],
  prog_det_teks: ["Membaca teks resepmu…", "Reading your recipe text…"],
  prog_det_foto: ["Membaca tulisan di foto resepmu…", "Reading the writing in your recipe photo…"],
  prog_det_bahan: [
    "Mencocokkan bahan dengan daftar bahan Racik…",
    "Matching ingredients with Racik's ingredient list…",
  ],
  prog_det_langkah_video: [
    "Mengurutkan langkah memasak dari videonya…",
    "Putting the cooking steps from the video in order…",
  ],
  prog_det_langkah_foto: [
    "Mengurutkan langkah memasak dari fotonya…",
    "Putting the cooking steps from the photo in order…",
  ],
  prog_det_langkah_teks: [
    "Mengurutkan langkah memasak dari teksnya…",
    "Putting the cooking steps from the text in order…",
  ],
  prog_det_rapikan: ["Merapikan takaran dan porsinya…", "Tidying up the amounts and portions…"],
  prog_det_lama: [
    "Masih menyusun. Yang ini butuh waktu lebih lama dari biasanya.",
    "Still working. This one is taking longer than usual.",
  ],
  prog_done: ["Selesai", "Done"],
  prog_now: ["Sedang berjalan", "In progress"],
  prog_time_head: ["Biasanya 30–60 detik.", "Usually 30–60 seconds."],
  prog_time_body: [
    "Video yang perlu didengarkan suaranya bisa sampai 90 detik.",
    "Videos that need listening to can take up to 90 seconds.",
  ],
  prog_time_head_suara: ["Biasanya 60–90 detik.", "Usually 60–90 seconds."],
  prog_time_body_suara: [
    "Mendengarkan suara video butuh waktu paling lama.",
    "Listening to a video's sound takes the longest.",
  ],
  prog_note: [
    "Kamu boleh menutup lembar ini. Resepnya tetap disusun, dan kami kabari saat siap.",
    "You can close this sheet. The recipe keeps being made, and we'll let you know when it's ready.",
  ],
  // the sign-in offer, redesigned 29 Okt 2026
  offer2_title: [
    "Simpan, tulis, dan bagikan resep andalanmu.",
    "Save, write and share your favourite recipes.",
  ],
  offer2_body: [
    "Buat akun gratis supaya resepmu aman, bisa dibagikan, dan bisa dibuka di semua perangkat.",
    "Make a free account so your recipes stay safe, can be shared, and open on every device.",
  ],
  offer2_save_t: ["Simpan resep favorit", "Keep your favourite recipes"],
  offer2_save_b: [
    "Resep dari link Instagram, TikTok, atau blog tersimpan di akunmu, tidak hilang saat ganti HP.",
    "Recipes from Instagram, TikTok or blog links are kept in your account, even when you change phones.",
  ],
  offer2_share_t: ["Tulis dan bagikan resep andalanmu", "Write and share your best recipes"],
  offer2_share_b: [
    "Bagikan resep buatanmu agar bisa dicoba orang lain, dan lihat berapa orang yang memasaknya.",
    "Share your own recipes for others to try, and see how many people cooked them.",
  ],
  offer2_sync_t: ["Tetap tersimpan di akun", "Kept in your account"],
  offer2_sync_b: [
    "Buka koleksi resepmu kapan saja, dari laptop maupun HP.",
    "Open your recipe collection any time, from a laptop or a phone.",
  ],
  offer2_email: ["Daftar dengan Email", "Sign up with email"],
  offer2_or: ["atau", "or"],
  offer2_free_note: [
    "Tanpa akun pun {n} resep, takaran, dan mode masak tetap jalan.",
    "Without an account, all {n} recipes, measurements and cook mode still work.",
  ],
  offer2_terms_pre: [
    "Dengan membuat akun, kamu menyetujui",
    "By creating an account, you agree to Racik's",
  ],
  offer2_terms_and: ["dan", "and"],
  offer2_terms_post: [" Racik.", "."],

  continue_facebook: ["Lanjut dengan Facebook", "Continue with Facebook"],
  continue_apple: ["Lanjut dengan Apple", "Continue with Apple"],

  // writing
  write_recipe: ["Tulis resep sendiri", "Write your own recipe"],
  write_intro: [
    "Tulis sekali, dan resepnya punya namamu di atasnya. Kirim ke grup arisan lewat WhatsApp — mereka langsung bisa membukanya, tanpa memasang Racik. Setiap kali ada yang memasaknya, kamu tahu.",
    "Write it once, and it carries your name. Send it to a WhatsApp group — they open it straight away, without installing Racik. Every time someone cooks it, you'll know.",
  ],
  my_recipes: ["Resep yang kamu tulis", "Recipes you wrote"],
  draft: ["Draf", "Draft"],
  live: ["Sudah tayang", "Published"],
  hidden: ["Disembunyikan", "Hidden"],
  report: ["Laporkan", "Report"],
  block_author: ["Blokir penulis ini", "Block this author"],

  // ── interface copy moved into t() (design plan task 10) ──
  halaman_tidak_ditemukan: ["Halaman tidak ditemukan", "Page not found"],
  alamat_ini_tidak_ada_atau: [
    "Alamat ini tidak ada atau sudah dipindahkan.",
    "This address doesn't exist or has moved.",
  ],
  kembali_ke_beranda: ["Kembali ke beranda", "Back to home"],
  halaman_tidak_bisa_dibuka: ["Halaman tidak bisa dibuka", "This page couldn't open"],
  ada_gangguan_saat_membuka_halaman: [
    "Ada gangguan saat membuka halaman. Coba muat ulang atau kembali ke beranda.",
    "Something went wrong opening this page. Try reloading or go back home.",
  ],
  coba_lagi: ["Coba lagi", "Try again"],
  ke_beranda: ["Ke beranda", "Go home"],
  versi_baru_racik_tersedia: ["Versi baru Racik tersedia.", "A new version of Racik is ready."],
  muat_ulang: ["Muat ulang", "Reload"],
  ubah_jadi_resep: ["Ubah jadi resep", "Turn into a recipe"],
  dari_link_video_teks_resep: [
    "Dari link video, teks resep, atau foto resep. Hasilnya tersimpan di Koleksi.",
    "From a video link, recipe text or a photo of a recipe. It's saved in your Collection.",
  ],
  atau_tulis_resep_sendiri: ["Atau tulis resep sendiri", "Or write your own recipe"],
  dihapus_dari_favorit: ["Dihapus dari favorit", "Removed from favourites"],
  urungkan: ["Urungkan", "Undo"],
  dihapus: ["{title} dihapus", "{title} deleted"],
  dari_luar: ["Dari luar", "Imported"],
  favorit: ["Favorit", "Favourites"],
  koleksi_saya: ["Koleksi Saya", "My Collection"],
  belum_ada_resep_dari_luar: ["Belum ada resep dari luar.", "No imported recipes yet."],
  tambahkan_dari_link_video_teks: [
    "Tambahkan dari link video, teks, atau foto.",
    "Add one from a video link, text or a photo.",
  ],
  resep_yang_racik_susun_dari: [
    "Resep yang Racik susun dari video, teks, atau foto.",
    "Recipes Racik put together from videos, text or photos.",
  ],
  resep_dari_luar: ["Resep dari luar", "Imported recipes"],
  hapus: ["Hapus {title}", "Delete {title}"],
  belum_ada_resep_yang_disimpan: ["Belum ada resep yang disimpan.", "No saved recipes yet."],
  ketuk_tanda_di_resep_mana: [
    "Ketuk tanda ♡ di resep mana pun untuk menyimpannya.",
    "Tap ♡ on any recipe to save it.",
  ],
  cari_resep: ["Cari resep", "Find recipes"],
  resep_yang_ditandai_untuk_dibuka: [
    "Resep yang ditandai untuk dibuka lagi.",
    "Recipes you marked to come back to.",
  ],
  resep_favorit: ["Resep favorit", "Favourite recipes"],
  hapus_dari_favorit: ["Hapus {title} dari favorit", "Remove {title} from favourites"],
  resep: ["resep", "recipes"],
  daerah_lain: ["Daerah lain", "Other regions"],
  semua: ["Semua", "All"],
  lainnya: ["Lainnya", "More"],
  ayam: ["Ayam", "Chicken"],
  ikan_udang: ["Ikan & Udang", "Fish & Prawns"],
  telur: ["Telur", "Eggs"],
  tahu_tempe: ["Tahu & Tempe", "Tofu & Tempeh"],
  daging: ["Daging", "Meat"],
  menit: ["≤ {n} menit", "≤ {n} min"],
  sayur: ["Sayur", "Vegetables"],
  g_protein: ["≥ {g} g protein", "≥ {g} g protein"],
  daging_ikan_tahu_tempe: ["Daging, ikan, tahu & tempe", "Meat, fish, tofu & tempeh"],
  sayur_buah: ["Sayur & buah", "Vegetables & fruit"],
  bumbu: ["Bumbu", "Spices & aromatics"],
  sembako: ["Sembako", "Pantry staples"],
  bahan_di_dapur: ["Bahan di dapur", "In your kitchen"],
  temukan_masakan_baru: ["Temukan masakan baru", "Find something new to cook"],
  cari_resep_atau_bahan: ["Cari resep atau bahan", "Search recipes or ingredients"],
  hapus_pencarian: ["Hapus pencarian", "Clear search"],
  coba_cari_ayam_tempe_atau: [
    "Coba cari: ayam, tempe, atau rendang",
    "Try: ayam, tempe or rendang",
  ],
  resep_yang_perlu_dicek_atau: [
    "resep yang perlu dicek atau tidak halal disembunyikan.",
    "recipes that need checking or aren't halal are hidden.",
  ],
  ubah: ["Ubah", "Change"],
  pilih_protein_utama: ["Pilih protein utama", "Pick the main protein"],
  buka_favorit: ["Buka Favorit", "Open Favourites"],
  cari_dari_bahan_yang_ada: [
    "Cari dari bahan yang ada di dapur",
    "Search by what's in your kitchen",
  ],
  hapus_filter: ["Hapus filter", "Clear filters"],
  tidak_ada_resep_berbahan: ["Tidak ada resep berbahan “", "No recipes with “"],
  di_racik: ["” di Racik", "” in Racik"],
  kata_ini_dicari_persis_tanpa: [
    "Kata ini dicari persis, tanpa tebakan ejaan, supaya tidak ada resep yang salah tampil.",
    "This word is matched exactly, with no spelling guesses, so no wrong recipe shows up.",
  ],
  belum_ada_resep_yang_cocok: ["Belum ada resep yang cocok", "No matching recipes yet"],
  coba_gunakan_nama_bahan_yang: [
    "Coba gunakan nama bahan yang lebih umum atau hapus filter.",
    "Try a more common ingredient name or clear the filters.",
  ],
  kembali_ke_eksplor: ["Kembali ke Eksplor", "Back to Explore"],
  cari_bahan_mis_tempe: ["Cari bahan, mis. tempe", "Search ingredients, e.g. tempe"],
  cari_bahan: ["Cari bahan", "Search ingredients"],
  resep_cocok: ["{v1} resep cocok", "{v1} matching recipes"],
  belum_ada_bahan_dipilih: ["Belum ada bahan dipilih", "No ingredients picked yet"],
  lihat_resep: ["Lihat resep", "See recipes"],
  hapus_akun: ["Hapus akun", "Delete account"],
  akunmu_sudah_dihapus: ["Akunmu sudah dihapus", "Your account has been deleted"],
  semua_data_akunmu_sudah_kami: [
    "Semua data akunmu sudah kami hapus. Resep bawaan Racik tetap bisa kamu pakai tanpa akun.",
    "We've deleted all your account data. You can still use Racik's built-in recipes without an account.",
  ],
  kamu_bisa_menghapus_akun_racik: [
    "Kamu bisa menghapus akun Racik kapan saja, gratis, langsung dari aplikasi atau dari halaman ini.",
    "You can delete your Racik account any time, free, from the app or from this page.",
  ],
  caranya: ["Caranya", "How to"],
  buka_racik_lalu: ["Buka Racik, lalu", "Open Racik, then"],
  koleksi_pengaturan_akun_data_hapus: [
    "Koleksi › Pengaturan › Akun & data › Hapus akun",
    "Collection › Settings › Account & data › Delete account",
  ],
  atau_buka_halaman_ini: ["— atau buka halaman ini:", "— or open this page:"],
  racik_online_hapus_akun: ["racik.online/hapus-akun", "racik.online/hapus-akun"],
  masuk_dengan_email_atau_akun: [
    "Masuk dengan email atau akun Google yang sama dengan yang kamu pakai di Racik.",
    "Sign in with the same email or Google account you use in Racik.",
  ],
  ketuk: ["Ketuk", "Tap"],
  hapus_akunku: ["Hapus akunku", "Delete my account"],
  lalu_konfirmasi: [", lalu konfirmasi.", ", then confirm."],
  yang_dihapus: ["Yang dihapus", "What gets deleted"],
  akun_dan_alamat_email_atau: [
    "Akun dan alamat email atau login Google-mu.",
    "Your account and email address or Google sign-in.",
  ],
  profil_nama_dan_foto_profil: [
    "Profil: nama dan foto profil.",
    "Profile: name and profile photo.",
  ],
  koleksimu_resep_yang_disimpan_resep: [
    "Koleksimu: resep yang disimpan, resep dari luar, rencana belanja, catatan masak, dan penilaian.",
    "Your collection: saved recipes, imported recipes, shopping plan, cooking notes and ratings.",
  ],
  resep_yang_kamu_tulis_beserta: [
    "Resep yang kamu tulis, beserta fotonya.",
    "Recipes you wrote, with their photos.",
  ],
  laporan_dan_blokir_yang_kamu: [
    "Laporan dan blokir yang kamu buat.",
    "Reports and blocks you made.",
  ],
  data_racik_di_hp_yang: [
    "Data Racik di HP yang kamu pakai untuk menghapus.",
    "Racik data on the phone you use to delete.",
  ],
  penghapusan_langsung_berlaku_dan_tidak: [
    "Penghapusan langsung berlaku dan tidak bisa dibatalkan. Kalau mau menyimpan salinannya dulu, pakai",
    "Deletion is immediate and can't be undone. To keep a copy first, use",
  ],
  unduh_dataku: ["Unduh dataku", "Download my data"],
  di_pengaturan: ["di Pengaturan.", "in Settings."],
  racik_di_hp_lain_yang: [
    "Racik di HP lain yang masih terbuka tetap menyimpan salinan di HP itu sampai kamu menghapus datanya di sana (Pengaturan › Hapus semua data di HP ini). Butuh bantuan? Lihat kontak di",
    "Racik on another phone that's still open keeps a copy there until you erase its data on that phone (Settings › Erase all data on this phone). Need help? See the contact details in the",
  ],
  kebijakan_privasi: ["Kebijakan Privasi", "Privacy Policy"],
  racik_belum_tersambung_ke_server: [
    "Racik belum tersambung ke server, jadi akun belum bisa dihapus dari sini.",
    "Racik isn't connected to the server, so the account can't be deleted from here yet.",
  ],
  masuk_untuk_menghapus_akun: ["Masuk untuk menghapus akun", "Sign in to delete your account"],
  hapus_akunmu_untuk_selamanya: ["Hapus akunmu untuk selamanya?", "Delete your account for good?"],
  akun_profil_koleksi_resep_resep: [
    "Akun, profil, koleksi resep, resep yang kamu tulis, dan foto-fotomu akan dihapus dari server Racik dan dari HP ini.",
    "Your account, profile, recipe collection, the recipes you wrote and your photos will be deleted from Racik's server and from this phone.",
  ],
  ini_tidak_bisa_dibatalkan: ["Ini tidak bisa dibatalkan.", "This can't be undone."],
  sarapan: ["Sarapan", "Breakfast"],
  makan_siang: ["Makan siang", "Lunch"],
  makan_malam: ["Makan malam", "Dinner"],
  camilan: ["Camilan", "Snacks"],
  memuat_racik: ["Memuat Racik…", "Loading Racik…"],
  masak_apa: ["Masak apa ", "What to cook "],
  ganti_waktu_makan_sekarang: ["Ganti waktu makan, sekarang: {label}", "Change meal, now: {label}"],
  masak_untuk: ["Masak untuk ", "Cooking for "],
  takaran_resep_ikut_jumlah_ini: [
    "Takaran resep ikut jumlah ini.",
    "Recipe amounts follow this number.",
  ],
  kurangi_jumlah_orang: ["Kurangi jumlah orang", "Fewer people"],
  tambah_jumlah_orang: ["Tambah jumlah orang", "More people"],
  sesuaikan_saran: ["Sesuaikan saran", "Tune suggestions"],
  hapus_semua: ["Hapus semua", "Clear all"],
  masak_untuk_kapan: ["Masak untuk kapan?", "Cooking for when?"],
  waktu_makan: ["Waktu makan", "Meal"],
  ikuti_jam_sekarang: ["Ikuti jam sekarang", "Follow the time of day"],
  sebentar_sedang_masuk: ["Sebentar, sedang masuk…", "One moment, signing in…"],
  dengan_masuk_kamu_setuju_dengan: [
    "Dengan masuk, kamu setuju dengan",
    "By signing in, you agree to the",
  ],
  racik_akun_gratis_dipakai_untuk: [
    "Racik. Akun gratis — dipakai untuk menyimpan resepmu supaya tidak hilang kalau ganti HP.",
    "of Racik. The account is free — it keeps your recipes safe if you change phones.",
  ],
  kalau_yang_datang_berupa_tautan: [
    "Kalau yang datang berupa tautan, ketuk saja tautannya di HP ini. Belum masuk? Cek folder Spam atau Promosi.",
    "If you got a link instead, just tap it on this phone. Nothing yet? Check your Spam or Promotions folder.",
  ],
  kirim_ulang_dalam_detik: ["Kirim ulang dalam {cooldown} detik", "Resend in {cooldown} seconds"],
  negara_takaran: ["Negara & takaran", "Country & measures"],
  dokumen: ["Dokumen", "Documents"],
  syarat_penggunaan: ["Syarat Penggunaan", "Terms of Use"],
  racik: ["Racik", "Racik"],
  tautan_ini_belum_bisa_dibuka: ["Tautan ini belum bisa dibuka", "This link can't be opened yet"],
  mungkin_tautannya_salah_ketik_sudah: [
    "Mungkin tautannya salah ketik, sudah dihapus, atau kamu sedang offline. Kode:",
    "The link may have a typo, been deleted, or you're offline. Code:",
  ],
  resep_yang_dibagikan: ["Resep yang dibagikan", "Shared recipe"],
  dibagikan: ["Dibagikan", "Shared"],
  lihat_resep_lengkap: ["Lihat resep lengkap", "See the full recipe"],
  tersimpan_di_koleksi: ["Tersimpan di Koleksi", "Saved in Collection"],
  simpan_ke_koleksi: ["Simpan ke Koleksi", "Save to Collection"],
  resep_ini_sudah_tidak_diterbitkan: [
    "Resep ini sudah tidak diterbitkan.",
    "This recipe is no longer published.",
  ],
  tonton_video_aslinya: ["Tonton video aslinya", "Watch the original video"],
  resep_ini_disusun_dari_video: [
    "Resep ini disusun dari video kreatornya. Tempel tautan videonya di Racik untuk melihat takarannya.",
    "This recipe was put together from the creator's video. Paste the video link into Racik to see the amounts.",
  ],
  resep_lain_dari: ["Resep lain dari @", "More recipes from @"],
  resep_ini_tidak_ada_di: [
    "Resep ini tidak ada di perangkat ini.",
    "This recipe isn't on this device.",
  ],
  buka_koleksi: ["Buka Koleksi", "Open Collection"],
  ditambahkan_ke_rencana: ["Ditambahkan ke rencana", "Added to plan"],
  pilih_hari: ["Pilih hari", "Pick a day"],
  sisa_bisa_dipakai: ["Sisa bisa dipakai", "Leftovers keep"],
  buka_sumber: ["Buka sumber", "Open source"],
  takaran_bumbunya_cuma_ditulis_di: [
    "Takaran bumbunya cuma ditulis di layar videonya, jadi Racik belum bisa membacanya. Buka videonya untuk melihat takarannya.",
    "The spice amounts only appear on screen in the video, so Racik can't read them yet. Open the video to see them.",
  ],
  jumlah_porsi_tidak_disebut_di: [
    "Jumlah porsi tidak disebut di videonya. Racik memakai",
    "The video doesn't say how many portions. Racik uses",
  ],
  porsi_diperkirakan_dari_bahan: [
    "Jumlah porsi tidak disebut di resepnya. Racik memperkirakan ±{n} porsi dari banyaknya bahan. Ubah kalau berbeda.",
    "The recipe doesn't say how many portions. Racik estimates ±{n} from the amounts. Change it if yours differs.",
  ],
  porsi_sebagai_dasar_hitungan: [
    "porsi sebagai dasar hitungan.",
    "portions as the starting point.",
  ],
  waktu: ["Waktu", "Time"],
  tingkat: ["Tingkat", "Difficulty"],
  belum_bisa_masuk_rencana: ["Belum bisa masuk rencana", "Can't go in the plan yet"],
  sudah_ada_di_rencana: ["Sudah ada di rencana", "Already in your plan"],
  rencana_sudah_penuh_resep: [
    "Rencana sudah penuh ({plan_max} resep)",
    "Plan is full ({plan_max} recipes)",
  ],
  tambah_ke_rencana: ["Tambah ke rencana", "Add to plan"],
  bahan: ["Bahan", "Ingredients"],
  untuk: ["Untuk", "For"],
  kurangi_porsi: ["Kurangi porsi", "Fewer portions"],
  tambah_porsi: ["Tambah porsi", "More portions"],
  resep_asli: ["Resep asli:", "Original recipe:"],
  porsi: ["porsi ·", "portions ·"],
  kembalikan: ["Kembalikan", "Reset"],
  bumbu_tidak_dikali_lurus_porsi: [
    "Bumbu tidak dikali lurus — porsi dua kali lipat tidak berarti cabainya dua kali.",
    "Spices don't scale in a straight line — double the portions doesn't mean double the chilli.",
  ],
  alat: ["Alat:", "Equipment:"],
  yang_dibutuhkan: ["Yang dibutuhkan:", "You'll need:"],
  resep_ini_perlu_timbangan_takaran: [
    "Resep ini perlu timbangan. Takaran gelas tidak cukup tepat untuk kue.",
    "This recipe needs a kitchen scale. Glass measures aren't exact enough for baking.",
  ],
  perkiraan_gizi: ["Perkiraan gizi", "Nutrition estimate"],
  langkah: ["Langkah", "Steps"],
  mulai_masak: ["Mulai masak ·", "Start cooking ·"],
  lompat_ke_bagian: ["Lompat ke bagian", "Jump to section"],
  waktunya_habis: ["Waktunya habis", "Time's up"],
  sudah: ["Sudah", "Done"],
  n1_menit: ["+1 menit", "+1 min"],
  sedang_berjalan: ["Sedang berjalan", "Running"],
  dijeda: ["Dijeda", "Paused"],
  waktu_langkah_ini: ["Waktu langkah ini", "Time for this step"],
  jeda: ["Jeda", "Pause"],
  lanjutkan: ["Lanjutkan", "Resume"],
  mulai_hitung: ["Mulai hitung", "Start timer"],
  ulangi: ["Ulangi", "Restart"],
  tetap_berjalan_walau_pindah_langkah: [
    "Tetap berjalan walau pindah langkah.",
    "Keeps running when you move to another step.",
  ],
  secukupnya: ["secukupnya", "secukupnya"],
  resepnya_tidak_ketemu: ["Resepnya tidak ketemu", "Recipe not found"],
  belum_ada_langkahnya: ["Belum ada langkahnya", "No steps yet"],
  lihat_bahan: ["Lihat bahan", "See ingredients"],
  keluar_dari_mode_masak: ["Keluar dari mode masak", "Leave cook mode"],
  dari: ["dari", "of"],
  melanjutkan_dari_langkah: ["Melanjutkan dari langkah", "Picking up from step"],
  mulai_dari_awal: ["Mulai dari awal", "Start over"],
  siapkan_dulu: ["Siapkan dulu", "Get these ready"],
  ketuk_kalau_sudah_siap: ["Ketuk kalau sudah siap.", "Tap when ready."],
  bahan_lain_di_resep_ini: ["Bahan lain di resep ini", "Other ingredients in this recipe"],
  tidak_disebut_di_langkah_mana: [
    "Tidak disebut di langkah mana pun. Siapkan sekalian.",
    "Not named in any step. Get them ready too.",
  ],
  penghitung_waktu_yang_berjalan: ["Penghitung waktu yang berjalan", "Running timers"],
  waktunya: ["Waktunya!", "Time's up!"],
  dijeda_2: ["dijeda {v1}", "paused {v1}"],
  tampilkan_lebih_sedikit: ["Tampilkan lebih sedikit", "Show less"],
  lainnya_2: ["+{v1} lainnya", "+{v1} more"],
  sebelumnya: ["Sebelumnya", "Previous"],
  timer_masih_berjalan: ["Timer masih berjalan", "A timer is still running"],
  timer_tetap_berjalan_walau_kamu: [
    "Timer tetap berjalan walau kamu keluar. Buka mode masak lagi untuk melihatnya.",
    "Timers keep running when you leave. Open cook mode again to see them.",
  ],
  tetap_di_sini: ["Tetap di sini", "Stay here"],
  semua_bahan: ["Semua bahan", "All ingredients"],
  lebih_gampang_dari_perkiraan: ["Lebih gampang dari perkiraan", "Easier than expected"],
  pas_seperti_keterangannya: ["Pas seperti keterangannya", "About as described"],
  lebih_ribet_dari_perkiraan: ["Lebih ribet dari perkiraan", "Harder than expected"],
  sudah_dimasak: ["Sudah dimasak", "Cooked"],
  foto_hasil_masakanmu: ["Foto hasil masakanmu?", "A photo of what you made?"],
  hasil_masakan: ["Hasil masakan", "Your dish"],
  ambil_atau_pilih_foto: ["Ambil atau pilih foto", "Take or pick a photo"],
  bagikan: ["Bagikan", "Share"],
  kartunya_memakai_fotomu_lengkap_dengan: [
    "Kartunya memakai fotomu, lengkap dengan porsi, waktu, dan tautan ke resepnya.",
    "The card uses your photo, with the portions, time and a link to the recipe.",
  ],
  tanpa_foto_pun_bisa_kartunya: [
    "Tanpa foto pun bisa: kartunya memakai foto resep.",
    "No photo is fine too: the card uses the recipe photo.",
  ],
  penyimpanan_hp_sudah_penuh_jadi: [
    "Penyimpanan HP sudah penuh, jadi foto lama terpaksa dihapus. Resep dan rencana masak tetap aman.",
    "Your phone's storage is full, so older photos had to be removed. Recipes and the cooking plan are safe.",
  ],
  tadi_seberapa_ribet: ["Tadi seberapa ribet", "How hard was it"],
  dari_2: ["Dari", "From"],
  catatan: ["catatan:", "notes:"],
  keterangan_tingkat_kesulitan_muncul_setelah: [
    "Keterangan tingkat kesulitan muncul setelah tiga kali dicatat. Sebelum itu angkanya belum berarti apa-apa.",
    "A difficulty rating appears after three notes. Before that the numbers don't mean much.",
  ],
  siapa_yang_memasaknya: ["Siapa yang memasaknya", "Who cooked it"],
  racik_belum_tersambung_ke_server_2: [
    "Racik belum tersambung ke server, jadi angkanya belum bisa ditampilkan.",
    "Racik isn't connected to the server, so the numbers can't be shown yet.",
  ],
  masuk_untuk_memilih_nama_pengguna: [
    "Masuk untuk memilih nama pengguna dan melihat berapa orang membuka, menyimpan, dan memasak resep yang kamu bagikan.",
    "Sign in to pick a username and see how many people open, save and cook the recipes you share.",
  ],
  memuat: ["Memuat…", "Loading…"],
  tanpa_nama_tampilan: ["Tanpa nama tampilan", "No display name"],
  lihat_profil: ["Lihat profil", "View profile"],
  nama_pengguna: ["Nama pengguna", "Username"],
  dari_tautan_yang_kamu_bagikan: ["Dari tautan yang kamu bagikan", "From links you shared"],
  memuat_angka: ["Memuat angka…", "Loading numbers…"],
  angkanya_belum_bisa_diambil_sekarang: [
    "Angkanya belum bisa diambil sekarang. Coba lagi nanti.",
    "The numbers can't be loaded right now. Try again later.",
  ],
  belum_ada_setelah_selesai_memasak: [
    "Belum ada. Setelah selesai memasak, ketuk",
    "Nothing yet. After you finish cooking, tap",
  ],
  untuk_membuat_kartu_hasil_masakanmu: [
    "untuk membuat kartu hasil masakanmu. Angkanya muncul di sini.",
    "to make a card of your dish. The numbers show up here.",
  ],
  dimasak: ["Dimasak", "Cooked"],
  orang_lewat_tautanmu: ["orang lewat tautanmu.", "people through your link."],
  paling_banyak: ["Paling banyak:", "Most:"],
  kali_dibuka: ["kali dibuka", "opens"],
  dimasak_orang: [", dimasak {cooks} orang", ", cooked by {cooks} people"],
  kartu_story_status_dibuka: ["Kartu Story/Status dibuka", "Story/Status card opened"],
  kali_kartu_feed: ["kali, kartu feed", "times, feed card"],
  kali: ["kali", "times"],
  lebih_banyak_dibuka: [" — {v1} lebih banyak dibuka.", " — {v1} gets more opens."],
  dibuka: ["dibuka ·", "opens ·"],
  disimpan: ["disimpan ·", "saves ·"],
  dimasak_2: ["dimasak", "cooks"],
  satu_hp_dihitung_sekali_sehari: [
    "Satu HP dihitung sekali sehari per tautan. Ketukanmu sendiri tidak dihitung. Hanya kamu yang bisa melihat angka ini.",
    "Each phone counts once a day per link. Your own taps don't count. Only you can see these numbers.",
  ],
  tulis: ["Tulis", "Write"],
  terbit_dimasak: ["Terbit · dimasak {cookedCount}", "Published · cooked {cookedCount}"],
  belum_ada_resep_yang_kamu: [
    "Belum ada resep yang kamu terbitkan.",
    "You haven't published any recipes yet.",
  ],
  resep_andalanmu_takarannya_jelas: [
    "Resep andalanmu, takarannya jelas",
    "Your signature recipe, with clear amounts",
  ],
  tulis_resep_yang_biasa_kamu: [
    "Tulis resep yang biasa kamu masak di rumah. Racik membaca takarannya, jadi orang lain bisa memasaknya untuk berapa porsi pun. Draf tersimpan di HP ini; untuk menerbitkan, kamu perlu masuk.",
    "Write a recipe you cook at home. Racik reads the amounts, so others can cook it for any number of portions. Drafts stay on this phone; to publish, you need to sign in.",
  ],
  tulis_resep_baru: ["Tulis resep baru", "Write a new recipe"],
  resepku_siapa_yang_memasaknya: ["Resepku: siapa yang memasaknya", "My recipes: who cooked them"],
  sudah_punya_akun: ["Sudah punya akun?", "Already have an account?"],
  untuk_melihat_resep_yang_pernah: [
    "untuk melihat resep yang pernah kamu terbitkan.",
    "to see the recipes you've published.",
  ],
  membuka_draf: ["Membuka draf…", "Opening draft…"],
  menyimpan_resep: ["Menyimpan resep…", "Saving recipe…"],
  menerbitkan: ["Menerbitkan…", "Publishing…"],
  tersimpan_otomatis_di_hp_ini: [
    "Tersimpan otomatis di HP ini",
    "Saved automatically on this phone",
  ],
  resep_ini_disembunyikan_oleh_moderator: [
    "Resep ini disembunyikan oleh moderator",
    "This recipe was hidden by a moderator",
  ],
  kamu_masih_bisa_mengubahnya_tapi: [
    "Kamu masih bisa mengubahnya, tapi belum bisa menerbitkannya lagi.",
    "You can still edit it, but you can't publish it again yet.",
  ],
  foto_masakan: ["Foto masakan", "Photo of the dish"],
  foto_masakan_boleh_nanti: ["Foto masakan (boleh nanti)", "Photo of the dish (can wait)"],
  nama_resep: ["Nama resep", "Recipe name"],
  misalnya_sayur_asem_kampung: ["Misalnya: Sayur asem kampung", "For example: Sayur asem kampung"],
  untuk_berapa_porsi: ["Untuk berapa porsi", "How many portions"],
  waktu_masak_menit: ["Waktu masak (menit)", "Cooking time (minutes)"],
  satu_bahan_per_baris_takaran: [
    'Satu bahan per baris, takaran dulu: "500 gram daging sapi, potong dadu".',
    'One ingredient per line, amount first: "500 gram daging sapi, potong dadu".',
  ],
  bahan_2: ["Bahan {v1}", "Ingredient {v1}"],
  hapus_bahan: ["Hapus bahan {v1}", "Remove ingredient {v1}"],
  tambah_bahan: ["Tambah bahan", "Add ingredient"],
  cara_memasak: ["Cara memasak", "Method"],
  satu_langkah_per_kotak_tulis: [
    'Satu langkah per kotak. Tulis lamanya ("rebus 20 menit"), Racik memasang timernya.',
    'One step per box. Write how long ("rebus 20 menit") and Racik sets the timer.',
  ],
  langkah_2: ["Langkah {v1}", "Step {v1}"],
  hapus_langkah: ["Hapus langkah {v1}", "Remove step {v1}"],
  timer: ["Timer", "Timer"],
  tambah_langkah: ["Tambah langkah", "Add step"],
  catatan_boleh_kosong: ["Catatan (boleh kosong)", "Notes (optional)"],
  tips_asal_resep_atau_enak: [
    "Tips, asal resep, atau enak dimakan dengan apa.",
    "Tips, where the recipe comes from, or what it's good with.",
  ],
  resep_ini_dari_video_atau: [
    "Resep ini dari video atau tulisan orang lain",
    "This recipe is from someone else's video or writing",
  ],
  nama_kreatornya_akan_tertulis_di: [
    "Nama kreatornya akan tertulis di resep dan di kartu bagikan. Kamu tampil sebagai yang memasak.",
    "The creator's name will appear on the recipe and the share card. You appear as the cook.",
  ],
  kreator: ["@kreator", "@creator"],
  nama_kreator_asli: ["Nama kreator asli", "Original creator's name"],
  https_tautan_videonya: ["https://… (tautan videonya)", "https://… (the video link)"],
  tautan_sumber: ["Tautan sumber", "Source link"],
  hal_perlu_dilengkapi: ["{v1} hal perlu dilengkapi", "{v1} things to fill in"],
  sudah_bisa_terbit_cek_dulu: [
    "Sudah bisa terbit. Cek dulu ini:",
    "Ready to publish. Check this first:",
  ],
  resepnya_lengkap_dan_runtut: [
    "Resepnya lengkap dan runtut.",
    "The recipe is complete and in order.",
  ],
  masuk_dulu_untuk_menerbitkan: ["Masuk dulu untuk menerbitkan", "Sign in to publish"],
  drafnya_sudah_tersimpan_di_hp: [
    "Drafnya sudah tersimpan di HP ini, tidak akan hilang.",
    "The draft is saved on this phone and won't be lost.",
  ],
  pilih_nama_pengguna_untuk_resepmu: [
    "Pilih nama pengguna untuk resepmu",
    "Pick a username for your recipes",
  ],
  resepmu_sudah_terbit: ["Resepmu sudah terbit", "Your recipe is published"],
  bagikan_resep: ["Bagikan resep", "Share recipe"],
  lihat_halamannya: ["Lihat halamannya", "View its page"],
  simpan_draf: ["Simpan draf", "Save draft"],
  tarik_dari_publik: ["Tarik dari publik", "Unpublish"],
  terbitkan_saja: ["Terbitkan saja", "Publish anyway"],
  simpan_perubahan: ["Simpan perubahan", "Save changes"],
  periksa_terbitkan: ["Periksa & terbitkan", "Check & publish"],
  hapus_draf_ini: ["Hapus draf ini", "Delete this draft"],
  racik_belum_kenal_bahan_ini: [
    "Racik belum kenal bahan ini. Takarannya tetap ditulis apa adanya.",
    "Racik doesn't know this ingredient yet. Its amount is kept as written.",
  ],
  resep_ini_belum_bisa_dibuka: ["Resep ini belum bisa dibuka", "This recipe can't be opened yet"],
  mungkin_penulisnya_sudah_menariknya_atau: [
    "Mungkin penulisnya sudah menariknya, atau kamu sedang offline.",
    "The author may have taken it down, or you're offline.",
  ],
  resep_2: ["Resep @", "Recipes by @"],
  resep_tulisan_pengguna_racik: [
    "Resep tulisan pengguna Racik",
    "A recipe written by a Racik user",
  ],
  diadaptasi_dari: ["Diadaptasi dari", "Adapted from"],
  dimasak_orang_lewat_racik: [
    " · dimasak {cookedCount} orang lewat Racik",
    " · cooked by {cookedCount} people with Racik",
  ],
  resep_tulisan_pengguna_tidak_diberi: [
    "Resep tulisan pengguna tidak diberi label halal. Periksa sendiri bahan-bahannya.",
    "Recipes written by users have no halal label. Check the ingredients yourself.",
  ],
  buka_di_koleksi: ["Buka di Koleksi", "Open in Collection"],
  simpan_masak: ["Simpan & masak", "Save & cook"],
  racik_belum_kenal_bahan_berikut: [
    "Racik belum kenal bahan berikut, jadi takarannya ditulis apa adanya dan tidak ikut berubah dengan porsi:",
    "Racik doesn't know these ingredients yet, so their amounts are kept as written and don't change with portions:",
  ],
  laporkan_resep_ini: ["Laporkan resep ini", "Report this recipe"],
  laporkan_resep: ["Laporkan resep", "Report recipe"],
  belum_ada_di_racik: ["belum ada di Racik", "isn't on Racik yet"],
  periksa_ejaannya_atau_mungkin_kamu: [
    "Periksa ejaannya, atau mungkin kamu sedang offline.",
    "Check the spelling, or you may be offline.",
  ],
  dari_3: [" · dari {source_creator}", " · from {source_creator}"],
  menu_utama: ["Menu utama", "Main menu"],
  per_porsi: ["per porsi", "per portion"],
  dari_luar_2: ["Dari luar ·", "Imported ·"],
  soal_halal: ["Soal halal", "About halal"],
  punya_resep_dari_luar_racik: ["Punya resep dari luar Racik?", "Got a recipe from outside Racik?"],
  dari_link_video_teks_resep_2: [
    "Dari link video, teks resep, atau foto resep.",
    "From a video link, recipe text or a photo of a recipe.",
  ],
  tambah_resep: ["Tambah resep", "Add recipe"],
  dari_link_video_teks_atau: [
    "Dari link video, teks, atau foto",
    "From a video link, text or a photo",
  ],
  link_video: ["Link video", "Video link"],
  teks_resep: ["Teks resep", "Recipe text"],
  foto_resep: ["Foto resep", "Recipe photo"],
  aplikasi_videonya_sedang_menahan_permintaan: [
    "Aplikasi videonya sedang menahan permintaan",
    "The video app is holding back requests",
  ],
  videonya_tidak_bisa_dibuka: ["Videonya tidak bisa dibuka", "The video couldn't be opened"],
  instagram_tidak_membagikan_videonya: [
    "Keterangan Reels ini tidak memuat resep, dan Instagram tidak membagikan videonya ke aplikasi lain. Simpan videonya lalu unggah di sini, atau tempel teks resepnya.",
    "This Reel's caption has no recipe, and Instagram doesn't share its video with other apps. Save the video and upload it here, or paste the recipe text.",
  ],
  racik_belum_bisa_membaca_videonya: [
    "Racik belum bisa membaca videonya",
    "Racik couldn't read this video",
  ],
  keterangan_videonya_terlalu_pendek: [
    "Keterangan videonya terlalu pendek",
    "The video caption is too short",
  ],
  dengarkan_suara_videonya: ["Dengarkan suara videonya", "Listen to the video"],
  bisa_sampai_satu_menit_racik: [
    "Bisa sampai satu menit. Racik mendengarkan 3 menit pertama.",
    "Can take up to a minute. Racik listens to the first 3 minutes.",
  ],
  unggah_videonya: ["Unggah videonya", "Upload the video"],
  video_atau_rekaman_suara_paling: [
    "Video atau rekaman suara, paling besar 14 MB.",
    "A video or voice recording, up to 14 MB.",
  ],
  tempel_teks_resep: ["Tempel teks resep", "Paste the recipe text"],
  ubah_teksnya: ["Ubah teksnya", "Edit the text"],
  pilih_foto_lain: ["Pilih foto lain", "Pick other photos"],
  link_tiktok_reels_atau_youtube: [
    "Link TikTok, Instagram, atau YouTube",
    "TikTok, Instagram or YouTube link",
  ],
  gunakan_link_tiktok_instagram_atau: [
    "Gunakan link TikTok, Instagram, atau YouTube.",
    "Use a TikTok, Instagram or YouTube link.",
  ],
  belum_bisa_membaca_yang_kamu: [
    "Belum bisa membaca yang kamu salin",
    "Couldn't read what you copied",
  ],
  tempel_dari_clipboard: ["Tempel dari clipboard", "Paste from clipboard"],
  ambil_atau_pilih_foto_resep: ["Ambil atau pilih foto resep", "Take or pick a photo of a recipe"],
  bisa_berupa_tulisan_tangan_atau: [
    "Bisa berupa tulisan tangan atau resep cetak",
    "Handwritten or printed both work",
  ],
  tempel_bahan_dan_cara_memasak: [
    "Tempel bahan dan cara memasak di sini…",
    "Paste the ingredients and method here…",
  ],
  huruf: ["huruf", "characters"],
  dari_video_buka_videonya_tahan: [
    "Dari video: buka videonya, tahan keterangannya, lalu Salin. Tempel di sini.",
    "From a video: open it, press and hold the caption, then Copy. Paste it here.",
  ],
  teks_sependek_ini_biasanya_belum: [
    "Teks sependek ini biasanya belum memuat bahan dan langkah.",
    "Text this short usually doesn't have the ingredients and steps yet.",
  ],
  teksnya_terlalu_panjang_hapus_bagian: [
    "Teksnya terlalu panjang. Hapus bagian yang bukan bahan dan cara masak.",
    "The text is too long. Remove the parts that aren't ingredients or method.",
  ],
  boleh_sampai_4_foto_sekaligus: [
    "Boleh sampai 4 foto sekaligus, dari bahasa apa saja. Racik tidak menebak bagian yang tidak tertulis.",
    "Up to 4 photos at once, in any language. Racik doesn't guess what isn't written.",
  ],
  bisa_dari_bahasa_apa_saja: [
    "Bisa dari bahasa apa saja. Hanya video publik yang bisa dibaca dari link. Racik tidak menebak bagian yang tidak disebut.",
    "Any language works. Only public videos can be read from a link. Racik doesn't guess what isn't said.",
  ],
  bisa_dari_bahasa_apa_saja_2: [
    "Bisa dari bahasa apa saja. Racik tidak menebak bagian yang tidak tertulis.",
    "Any language works. Racik doesn't guess what isn't written.",
  ],
  racik_sedang_merapikan_bahan_takaran: [
    "Racik sedang merapikan bahan, takaran, dan langkahnya supaya enak diikuti.",
    "Racik is tidying the ingredients, amounts and steps so they're easy to follow.",
  ],
  mendengarkan_videonya: ["Mendengarkan videonya", "Listening to the video"],
  bisa_sampai_satu_menit_kalau: [
    "Bisa sampai satu menit. Kalau layar ini tertutup, resepnya tetap tersimpan begitu selesai.",
    "Can take up to a minute. If this screen closes, the recipe is still saved when it's done.",
  ],
  jatah_bulan_ini_sudah_habis: ["Jatah bulan ini sudah habis", "This month's allowance is used up"],
  kamu_sudah_menambah_resep_bulan: [
    "Kamu sudah menambah {limit} resep bulan ini. ",
    "You've added {limit} recipes this month. ",
  ],
  jatahnya_terisi_lagi_tanggal: ["Jatahnya terisi lagi tanggal", "It refills on"],
  n1_bulan_depan: ["1 bulan depan", "the 1st of next month"],
  resep_yang_sudah_tersimpan_tetap: [
    ". Resep yang sudah tersimpan tetap bisa dimasak kapan saja.",
    ". Recipes you've saved can still be cooked any time.",
  ],
  tutup: ["Tutup", "Close"],
  diterjemahkan_dari: ["Diterjemahkan dari", "Translated from"],
  takaran_asingnya_sudah_diubah_ke: [
    ". Takaran asingnya sudah diubah ke ukuran dapur.",
    ". Foreign measures were changed to kitchen measures.",
  ],
  bahan_ditulis_apa_adanya_takarannya: [
    "bahan ditulis apa adanya, takarannya tidak ikut dihitung ulang.",
    "ingredients kept as written; their amounts won't be recalculated.",
  ],
  periksa_kembali_bahan_takaran_dan: [
    "Periksa kembali bahan, takaran, dan langkah sebelum mulai memasak.",
    "Check the ingredients, amounts and steps before you start cooking.",
  ],
  lihat_di_koleksi: ["Lihat di Koleksi", "See in Collection"],
  resep_tersimpan: ["Resep tersimpan", "Recipe saved"],
  belum_lengkap: ["Belum lengkap", "Incomplete"],
  tandai: ["Tandai {name}", "Tick {name}"],
  ganti: ["Ganti", "Swap"],
  tidak_bisa_dibagi_lebih_kecil: ["Tidak bisa dibagi lebih kecil.", "Can't be split any smaller."],
  saran_saat_impor: ["Saran saat impor", "Suggested when imported"],
  rasanya_tidak_persis_sama_penggantinya: [
    "Rasanya tidak persis sama. Penggantinya cukup dekat untuk sekali masak.",
    "It won't taste exactly the same, but it's close enough for one cook.",
  ],
  pengganti: ["Pengganti", "Swap"],
  saran_dari_racik_saat_impor: [
    "Saran dari Racik saat impor. Rasanya tidak persis sama.",
    "Racik's suggestion from the import. It won't taste exactly the same.",
  ],
  perkiraan_gizi_per_porsi: ["Perkiraan gizi per porsi", "Nutrition estimate per portion"],
  perkiraan_gizi_belum_bisa_dihitung: [
    "Perkiraan gizi belum bisa dihitung — resepnya belum lengkap.",
    "Nutrition can't be estimated yet — the recipe is incomplete.",
  ],
  lihat_rincian_perkiraan_gizi: [
    "Lihat rincian perkiraan gizi",
    "See the nutrition estimate details",
  ],
  belum_bisa_dihitung: ["belum bisa dihitung", "can't be estimated yet"],
  lihat_rincian: ["Lihat rincian", "See details"],
  perkiraan_dari_bahan_standar_hasil: [
    "Perkiraan dari bahan standar. Hasil sebenarnya dapat berbeda menurut merek dan cara memasak.",
    "Estimated from standard ingredients. Actual values vary with brand and cooking method.",
  ],
  dari_mana_angka_gizinya: ["Dari mana angka gizinya", "Where the nutrition numbers come from"],
  tampilkan_gizi: ["Tampilkan gizi", "Show nutrition"],
  seluruh_resep: ["Seluruh resep", "Whole recipe"],
  per_porsi_2: ["Per porsi", "Per portion"],
  untuk_porsi_sesuai_jumlah_porsi: [
    "Untuk {servings} porsi, sesuai jumlah porsi di halaman resep.",
    "For {servings} portions, matching the recipe page.",
  ],
  untuk_satu_porsi: ["Untuk satu porsi.", "For one portion."],
  kalori: ["Kalori", "Calories"],
  dihitung_dari: ["Dihitung dari", "Counted from"],
  bahan_yang_ada_takarannya: ["bahan yang ada takarannya.", "ingredients with an amount."],
  kalori_4_protein_4_karbo: [
    "Kalori = 4 × protein + 4 × karbo + 9 × lemak, dan hanya dihitung kalau semua bahan itu dikenal Racik.",
    "Calories = 4 × protein + 4 × carbs + 9 × fat, and only counted when Racik knows every ingredient.",
  ],
  bahan_penyumbang_terbesar: ["Bahan penyumbang terbesar", "Biggest contributors"],
  pilih_zat_gizi: ["Pilih zat gizi", "Choose a nutrient"],
  belum_bisa_dihitung_untuk_resep: [
    "Belum bisa dihitung untuk resep ini.",
    "Can't be estimated for this recipe yet.",
  ],
  tambah_resep_dari_luar: ["Tambah resep dari luar", "Add recipes from anywhere"],
  takaran_yang_familiar: ["Takaran yang familiar", "Familiar measures"],
  masakan_nusantara: ["Masakan Nusantara", "Indonesian home cooking"],
  gizi_lebih_mudah_dipahami: ["Gizi lebih mudah dipahami", "Nutrition made simple"],
  dapur_rumahan: ["@dapur_rumahan", "@dapur_rumahan"],
  rendang_empuk_tanpa_panci_presto: [
    "Rendang empuk tanpa panci presto 🔥",
    "Tender rendang, no pressure cooker 🔥",
  ],
  tempel_link_di_sini: ["Tempel link di sini", "Paste a link here"],
  n1_sdm: ["1 sdm", "1 sdm"],
  n1_sdt: ["1 sdt", "1 sdt"],
  n1_gelas_belimbing: ["1 gelas belimbing", "1 gelas belimbing"],
  n1_ons: ["1 ons", "1 ons"],
  konversi_takaran: ["Konversi takaran", "Measure conversion"],
  per_porsi_3: ["· per porsi", "· per portion"],
  protein: ["Protein", "Protein"],
  perkiraan_berdasarkan_bahan_dan_porsi: [
    "Perkiraan berdasarkan bahan dan porsi",
    "Estimated from ingredients and portions",
  ],
  perkiraan_dari_bahan_standar_nilai: [
    "* Perkiraan dari bahan standar. Nilai sebenarnya bisa berbeda.",
    "* Estimated from standard ingredients. Actual values may differ.",
  ],
  sehari_hari_di_rumah: ["Sehari-hari di rumah", "Everyday at home"],
  bekal_meal_prep: ["Bekal / meal prep", "Packed meals / meal prep"],
  acara_tamu: ["Acara & tamu", "Events & guests"],
  untuk_dijual: ["Untuk dijual", "To sell"],
  biasanya_masak_untuk_apa: ["Biasanya masak untuk apa?", "What do you usually cook for?"],
  biasanya_masak_untuk_berapa_orang: [
    "Biasanya masak untuk berapa orang?",
    "How many people do you usually cook for?",
  ],
  apa_yang_paling_penting_saat: [
    "Apa yang paling penting saat memilih resep?",
    "What matters most when choosing a recipe?",
  ],
  protein_apa_yang_paling_sering: [
    "Protein apa yang paling sering dimasak?",
    "Which proteins do you cook most?",
  ],
  orang: ["orang", "people"],
  simpan_dan_mulai: ["Simpan dan mulai", "Save and start"],
  perkiraan_per_porsi: ["Perkiraan per porsi:", "Estimate per portion:"],
  dihapus_dari_rencana: ["Dihapus dari rencana", "Removed from plan"],
  belum_dijadwalkan: ["Belum dijadwalkan", "Not scheduled"],
  mnt: ["mnt", "min"],
  pilih_hari_untuk: ["{day}: pilih hari untuk {title}", "{day}: pick a day for {title}"],
  hari: ["Hari", "Day"],
  kurangi_porsi_2: ["Kurangi porsi {title}", "Fewer portions of {title}"],
  porsi_2: ["{servings} porsi", "{servings} portions"],
  tambah_porsi_2: ["Tambah porsi {title}", "More portions of {title}"],
  hapus_dari_rencana: ["Hapus {title} dari rencana", "Remove {title} from plan"],
  rencana_masak: ["Rencana masak", "Cooking plan"],
  resep_minggu_ini_daftar_belanja: [
    "resep minggu ini. Daftar belanja dibuat otomatis dari bahan yang dibutuhkan.",
    "recipes this week. The shopping list is built automatically from the ingredients you need.",
  ],
  hari_ini: ["Hari ini", "Today"],
  tambah_resep_ke_rencana: ["Tambah resep ke rencana", "Add a recipe to the plan"],
  pilih_resep: ["Pilih resep", "Pick a recipe"],
  resep_3: ["resep ·", "recipes ·"],
  bahan_3: ["bahan", "ingredients"],
  sudah_dibeli: ["sudah dibeli", "bought"],
  bahan_yang_sama_dari_beberapa: [
    'Bahan yang sama dari beberapa resep sudah dijumlahkan, walau satuannya berbeda (misalnya siung dan gram). "Beli" menunjukkan jumlah yang biasa dijual di pasar. Tandai "Ada di rumah" untuk bahan yang tidak perlu dibeli.',
    'The same ingredient from several recipes is added up, even in different units (like siung and grams). "Buy" shows the amount usually sold at the market. Mark "At home" for anything you don\'t need to buy.',
  ],
  daftar_belanja: ["Daftar belanja", "Shopping list"],
  secukupnya_2: ["(+ secukupnya)", "(+ to taste)"],
  sudah_dibeli_2: ["Sudah dibeli", "Bought"],
  beli: ["Beli:", "Buy:"],
  biasanya_sudah_ada_cek_dapur: [
    "Biasanya sudah ada — cek dapur",
    "Usually at home — check the kitchen",
  ],
  untuk_2: ["Untuk:", "For:"],
  sudah_ada_di_rumah: ["{name} sudah ada di rumah", "{name} is already at home"],
  ada_di_rumah: ["Ada di rumah", "At home"],
  sudah_ada_di_rumah_2: ["Sudah ada di rumah (", "Already at home ("],
  perlu_dibeli: ["Perlu dibeli", "Need to buy"],
  bagikan_daftar_belanja: ["Bagikan daftar belanja", "Share shopping list"],
  salin_daftar: ["Salin daftar", "Copy list"],
  pindai_buka_di_hp: ["Pindai untuk buka di HP", "Scan to open on your phone"],
  qr_buka_di_hp_label: ["Kode QR untuk membuka resep ini di HP", "QR code to open this recipe on your phone"],
  segera_di_google_play: ["Segera di Google Play", "Coming soon to Google Play"],
  resep_sudah_tersimpan_buka_di_hp: ["Atau buka Racik di HP, resep ini sudah tersimpan.", "Or open Racik on your phone, this recipe is already saved."],
  masuk_gratis_simpan_semua_perangkat: ["Masuk gratis untuk simpan resep dan buka di semua perangkatmu.", "Sign in free to save recipes and open them on all your devices."],
  resep_ini_sudah_tersimpan_di_komputer: ["Resep ini sudah tersimpan di komputer ini. Dengan akun, resepnya ikut terbuka di HP juga.", "This recipe is saved on this computer. With an account, it opens on your phone too."],
  masuk_dengan_email: ["Masuk dengan email", "Sign in with email"],
  simpan: ["Simpan", "Save"],
  tersimpan: ["Tersimpan", "Saved"],
  tonton: ["Tonton", "Watch"],
  tonton_video_asli: ["Tonton video aslinya di tab baru", "Watch the original video in a new tab"],
  daftar_disalin: ["Daftar belanja disalin.", "Shopping list copied."],
  daftar_gagal_disalin: [
    "Daftar belum bisa disalin. Coba lagi.",
    "Couldn't copy the list. Try again.",
  ],
  kosongkan_rencana: ["Kosongkan rencana", "Clear plan"],
  belum_ada_rencana_masak: ["Belum ada rencana masak", "No cooking plan yet"],
  tambahkan_resep_untuk_membuat_daftar: [
    "Tambahkan resep untuk membuat daftar belanja otomatis.",
    "Add recipes to build a shopping list automatically.",
  ],
  hari_masak: ["Hari masak", "Cooking day"],
  kosongkan_rencana_2: ["Kosongkan rencana?", "Clear the plan?"],
  semua_resep_centang_belanja_dan: [
    'Semua resep, centang belanja, dan daftar "ada di rumah" akan dihapus.',
    'All recipes, shopping ticks and the "at home" list will be removed.',
  ],
  batal: ["Batal", "Cancel"],
  kosongkan: ["Kosongkan", "Clear"],
  akun_racik: ["Akun Racik", "Racik account"],
  baca_dulu: ["Baca dulu", "Read first"],
  apa_yang_disimpan_saat_kamu: [
    "— apa yang disimpan saat kamu punya akun.",
    "— what's stored when you have an account.",
  ],
  akun_data: ["Akun & data", "Account & data"],
  kamu_sudah_masuk: ["Kamu sudah masuk", "You're signed in"],
  belum_masuk: ["Belum masuk", "Not signed in"],
  salinan_semua_data_racik_milikmu: [
    "Salinan semua data Racik milikmu dalam satu berkas (JSON).",
    "A copy of all your Racik data in one file (JSON).",
  ],
  hapus_semua_data_di_hp: ["Hapus semua data di HP ini", "Erase all data on this phone"],
  keluar_dari_akun: ["Keluar dari akun?", "Sign out?"],
  resep_rencana_belanja_dan_catatan: [
    "Resep, rencana belanja, dan catatan masakmu akan dihapus dari HP ini, tapi tetap aman di akunmu. Masuk lagi kapan saja untuk mengambilnya.",
    "Your recipes, shopping plan and cooking notes will be removed from this phone but stay safe in your account. Sign in any time to get them back.",
  ],
  ukuran_tulisan_satuan_dan_jumlah: [
    "Ukuran tulisan, satuan, dan jumlah porsi tetap seperti sekarang.",
    "Text size, units and portion count stay as they are.",
  ],
  ada_perubahan_yang_belum_tersimpan: [
    "Ada perubahan yang belum tersimpan",
    "Some changes aren't saved yet",
  ],
  perubahan_terakhir_di_hp_ini: [
    "Perubahan terakhir di HP ini belum sempat dikirim ke akunmu (sepertinya tidak ada internet). Kalau keluar sekarang, perubahan itu hilang.",
    "The latest changes on this phone haven't reached your account (there seems to be no internet). If you sign out now, they'll be lost.",
  ],
  sambungkan_internet_lalu_coba_lagi: [
    "Sambungkan internet lalu coba lagi, atau keluar saja.",
    "Connect to the internet and try again, or sign out anyway.",
  ],
  hapus_semua_data_di_hp_2: ["Hapus semua data di HP ini?", "Erase all data on this phone?"],
  hapus_akun_juga: ["Hapus akun juga", "Delete the account too"],
  semua_data_racik_di_hp: [
    "Semua data Racik di HP ini dihapus dan kamu keluar dari akun di HP ini. Pengaturan kembali ke awal.",
    "All Racik data on this phone is erased and you're signed out here. Settings go back to the start.",
  ],
  akunmu_tidak_terhapus_resepmu_tetap: [
    "Akunmu tidak terhapus: resepmu tetap aman di akun dan kembali saat kamu masuk lagi.",
    "Your account isn't deleted: your recipes stay safe there and come back when you sign in again.",
  ],
  mau_menghapus_akun_dan_semua: [
    "Mau menghapus akun dan semua isinya? Pilih “Hapus akun juga”.",
    "Want to delete the account and everything in it? Choose “Delete the account too”.",
  ],
  koleksimu: ["Koleksimu", "Your collection"],
  resep_4: [" ({count} resep)", " ({count} recipes)"],
  resep_dari_luar_rencana_belanja: [
    ", resep dari luar, rencana belanja, catatan masak, foto, dan pengaturan akan hilang dari HP ini.",
    ", imported recipes, shopping plan, cooking notes, photos and settings will be gone from this phone.",
  ],
  simpan_resepmu_ke_akun: ["Simpan resepmu ke akun", "Keep your recipes in an account"],
  resep_dari_luar_ini_sudah: [
    "Resep dari luar ini sudah ada di HP-mu. ",
    "This imported recipe is on your phone. ",
  ],
  resep_ini_sudah_tersimpan_di: [
    "Resep ini sudah tersimpan di HP-mu. ",
    "This recipe is saved on your phone. ",
  ],
  masuk_gratis_lalu_resep_simpanan: [
    "Masuk gratis, lalu resep simpanan, resep dari luar, dan rencana belanjamu ikut tersimpan di akun — aman walau HP hilang atau ganti.",
    "Sign in for free and your saved recipes, imported recipes and shopping plan are kept in your account — safe even if you lose or change phones.",
  ],
  masuk_atau_daftar_gratis: ["Masuk atau daftar gratis", "Sign in or sign up free"],
  untuk_sekarang_resepnya_tetap_ada: [
    "Untuk sekarang resepnya tetap ada di HP ini.",
    "For now the recipe stays on this phone.",
  ],
  gabungkan_resep_di_hp_ini: [
    "Gabungkan {count} resep di HP ini ke akunmu?",
    "Add the {count} recipes on this phone to your account?",
  ],
  ada: ["Ada", "There are"],
  resep_yang_kamu_simpan_di: [
    "resep yang kamu simpan di HP ini sebelum masuk. Gabungkan supaya ikut tersimpan di akunmu dan muncul di HP lain.",
    "recipes you saved on this phone before signing in. Add them so they're kept in your account and show on other phones.",
  ],
  gabungkan_ke_akunku: ["Gabungkan ke akunku", "Add to my account"],
  jangan_pakai_isi_akunku_saja: ["Jangan, pakai isi akunku saja", "No, just use my account"],
  kalau_tidak_digabung_resep_di: [
    "Kalau tidak digabung, resep di HP ini dihapus dari HP ini dan diganti isi akunmu.",
    "If you don't add them, the recipes on this phone are replaced by what's in your account.",
  ],
  sebentar: ["Sebentar…", "One moment…"],
  orang_lain_hanya_melihat_nama: [
    "Orang lain hanya melihat nama pengguna ini dan resep yang kamu terbitkan. Nama akunmu tetap pribadi.",
    "Others only see this username and the recipes you publish. Your account name stays private.",
  ],
  dapur_sore: ["dapur.sore", "dapur.sore"],
  n3_24_huruf_kecil_angka: [
    "3–24 huruf kecil, angka, titik, atau garis bawah.",
    "3–24 lowercase letters, numbers, dots or underscores.",
  ],
  nama_tampilan_boleh_kosong: ["Nama tampilan (boleh kosong)", "Display name (optional)"],
  kosongkan_kalau_cukup_nama_pengguna: [
    "Kosongkan kalau cukup nama pengguna",
    "Leave empty if the username is enough",
  ],
  menyimpan: ["Menyimpan…", "Saving…"],
  simpan_nama_pengguna: ["Simpan nama pengguna", "Save username"],
  takarannya_jelas: ["Takarannya jelas", "Clear amounts"],
  racik_menghitung_ulang_takaran_resep: [
    "Racik menghitung ulang takaran resep rumahan sesuai jumlah porsimu, lalu menemanimu memasak langkah demi langkah. Gratis, tanpa daftar.",
    "Racik recalculates home recipes for your number of portions, then cooks with you step by step. Free, no sign-up.",
  ],
  buka_di_racik: ["Buka di Racik", "Open in Racik"],
  resep_diterbitkan: ["{count} resep diterbitkan", "{count} recipes published"],
  belum_ada_resep_yang_diterbitkan: [
    "Belum ada resep yang diterbitkan",
    "No published recipes yet",
  ],
  story_status: ["Story / Status", "Story / Status"],
  feed: ["Feed", "Feed"],
  ukuran_kartu: ["Ukuran kartu", "Card size"],
  kartu: ["Kartu {title}", "{title} card"],
  menyiapkan_kartu: ["Menyiapkan kartu…", "Preparing the card…"],
  simpan_gambar: ["Simpan gambar", "Save image"],
  salin_tautan: ["Salin tautan", "Copy link"],
  mau_tahu_berapa_orang_yang: [
    "Mau tahu berapa orang yang membuka dan memasaknya?",
    "Want to know how many people open and cook it?",
  ],
  masuk_dan_pilih_nama_pengguna: ["Masuk dan pilih nama pengguna", "Sign in and pick a username"],
  tautan_pendek: ["Tautan pendek", "Short link"],
  r_belum_bisa_dibuat_sekarang: [
    "/r/… belum bisa dibuat sekarang, jadi kartu ini memakai tautan resep biasa.",
    "A /r/… link can't be made right now, so this card uses the regular recipe link.",
  ],

  // ── interface copy moved into t() (design plan task 10) ──
  pilih_bahan_yang_ada_hasil: [
    "Pilih bahan yang ada. Hasil berubah setiap kali pilihan ditambah.",
    "Pick what you have. Results update with each pick.",
  ],
  ya_hapus_akunku: ["Ya, hapus akunku", "Yes, delete my account"],
  hapus_dari_favorit_2: ["Hapus dari favorit", "Remove from favourites"],
  simpan_ke_favorit: ["Simpan ke favorit", "Save to favourites"],
  resep_ini_tidak_ada_di_2: [
    "Resep ini tidak ada di HP ini. Mungkin sudah dihapus, atau disimpan di HP lain.",
    "This recipe isn't on this phone. It may have been deleted, or saved on another phone.",
  ],
  resep_ini_belum_punya_cara: [
    "Resep ini belum punya cara masak, jadi mode masak belum bisa dipakai. Bahannya masih bisa dilihat.",
    "This recipe has no method yet, so cook mode can't be used. You can still see the ingredients.",
  ],
  keluar_dari_mode_masak_2: ["Keluar dari mode masak?", "Leave cook mode?"],
  takaran_untuk_porsi: ["Takaran untuk {servings} porsi", "Amounts for {servings} portions"],
  tanpa_judul: ["Tanpa judul", "Untitled"],
  resep_5: ["Resep", "Recipe"],
  moderator_racik_akan_memeriksanya: [
    "Moderator Racik akan memeriksanya.",
    "A Racik moderator will review it.",
  ],
  tunggu_sebentar_lalu_coba_lagi: [
    "Tunggu sebentar lalu coba lagi, atau tempel teks resepnya di bawah.",
    "Wait a moment and try again, or paste the recipe text below.",
  ],
  mungkin_sudah_dihapus_atau_disetel: [
    "Mungkin sudah dihapus atau disetel privat. Kalau kamu punya teks resepnya, tempel di bawah.",
    "It may have been deleted or set to private. If you have the recipe text, paste it below.",
  ],
  tempel_teks_resep_lengkapnya_di: [
    "Racik sudah membaca keterangan dan mencoba mendengarkan videonya, tapi tidak berhasil. Tempel teks resepnya di bawah, atau unggah videonya.",
    "Racik read the caption and tried to listen to the video, but couldn't. Paste the recipe text below, or upload the video.",
  ],
  masukkan_link_video_teks_resep: [
    "Masukkan link video atau foto resep, dari bahasa apa saja. Racik menyusun bahan, takaran, dan langkahnya dalam Bahasa Indonesia.",
    "Add a video link or a photo of a recipe, in any language. Racik writes the ingredients, amounts and steps in Bahasa Indonesia.",
  ],
  tempel_langsung_di_kolomnya: ["Tempel langsung di kolomnya.", "Paste straight into the box."],
  tempel_teksnya_langsung_di_kolomnya: [
    "Tempel teksnya langsung di kolomnya.",
    "Paste the text straight into the box.",
  ],
  pengganti_2: ["Pengganti {name}", "Swap for {name}"],
  simpan_resep_tanpa_memutar_ulang: [
    "Simpan resep tanpa memutar ulang video",
    "Save recipes without replaying the video",
  ],
  masukkan_link_video_teks_atau: [
    "Masukkan link video, teks, atau foto. Racik akan menyusun bahan, takaran, dan langkah memasaknya.",
    "Add a video link, text or a photo. Racik lays out the ingredients, amounts and cooking steps.",
  ],
  mulai: ["Mulai", "Get started"],
  gunakan_takaran_yang_mudah_dipakai: [
    "Gunakan takaran yang mudah dipakai",
    "Use measures that are easy to follow",
  ],
  lihat_bahan_dalam_gram_sendok: [
    "Lihat bahan dalam gram, sendok, gelas, atau ukuran rumahan lain yang lebih praktis di dapur.",
    "See ingredients in grams, spoons, glasses or other kitchen measures that are handier to use.",
  ],
  ratusan_resep_dari_berbagai_daerah: [
    "Ratusan resep dari berbagai daerah",
    "Hundreds of recipes from across Indonesia",
  ],
  dari_rendang_minang_sampai_papeda: [
    "Dari rendang Minang sampai papeda Papua, temukan resep dengan bahan, takaran, dan langkah yang jelas.",
    "From Minang rendang to Papuan papeda, find recipes with clear ingredients, amounts and steps.",
  ],
  lihat_perkiraan_protein_per_porsi: [
    "Lihat perkiraan protein per porsi",
    "See estimated protein per portion",
  ],
  setiap_resep_menampilkan_perkiraan_protein: [
    "Setiap resep menampilkan perkiraan protein berdasarkan bahan dan jumlah porsinya.",
    "Every recipe shows an estimate of protein from its ingredients and portions.",
  ],
  ayo_mulai_masak: ["Ayo Mulai Masak", "Let's start cooking"],
  makan_sendiri_atau_bersama_keluarga: [
    "Makan sendiri atau bersama keluarga",
    "For yourself or the family",
  ],
  masak_sekali_untuk_beberapa_hari: [
    "Masak sekali untuk beberapa hari",
    "Cook once for several days",
  ],
  arisan_syukuran_kumpul_keluarga: [
    "Arisan, syukuran, kumpul keluarga",
    "Gatherings, celebrations, family get-togethers",
  ],
  katering_atau_jualan_kecil_kecilan: [
    "Katering atau jualan kecil-kecilan",
    "Catering or a small food business",
  ],
  pilih_yang_paling_sering_porsinya: [
    "Pilih yang paling sering. Porsinya bisa diatur di langkah berikutnya.",
    "Pick the one you do most. You can set portions in the next step.",
  ],
  takaran_bahan_akan_langsung_menyesuaikan: [
    "Takaran bahan akan langsung menyesuaikan jumlah ini.",
    "Ingredient amounts adjust to this number right away.",
  ],
  pilih_satu_atau_beberapa_agar: [
    "Pilih satu atau beberapa agar saran lebih sesuai.",
    "Pick one or more so suggestions fit better.",
  ],
  racik_akan_menampilkan_lebih_banyak: [
    "Racik akan menampilkan lebih banyak pilihan yang relevan.",
    "Racik will show more of what fits.",
  ],
  keluar_saja: ["Keluar saja", "Sign out anyway"],
  hapus_dari_hp_ini: ["Hapus dari HP ini", "Erase from this phone"],
  supaya_tidak_hilang_kalau_ganti: [
    "Supaya tidak hilang kalau ganti HP.",
    "So nothing is lost if you change phones.",
  ],
  kartu_hasil_masakanmu_siap_untuk: [
    "Kartu hasil masakanmu, siap untuk Story, Status, atau feed.",
    "A card of your dish, ready for Story, Status or your feed.",
  ],

  // ── interface copy moved into t() (design plan task 10) ──
  resepnya_belum_tertulis_di_keterangan: [
    "Videonya sepertinya tidak berisi resep.",
    "This video doesn't seem to contain a recipe.",
  ],
  bahan_dan_langkahnya_tidak_ada: [
    "Racik tidak menemukan bahan dan langkah memasak di keterangan maupun suara videonya. Coba link lain, atau tempel teks resepnya.",
    "Racik found no ingredients or steps in the caption or the audio. Try another link, or paste the recipe text.",
  ],
  resepnya_tidak_terdengar_di_video: [
    "Resepnya tidak terdengar di video ini",
    "No recipe could be heard in this video",
  ],
  racik_sudah_mendengarkan_videonya_tapi: [
    "Racik sudah mendengarkan videonya, tapi bahan dan langkahnya tidak disebut. Kalau resepnya ada di layar atau di keterangan, tempel teksnya.",
    "Racik listened to the video, but the ingredients and steps aren't said out loud. If the recipe is on screen or in the caption, paste the text.",
  ],
  belum_ada_resep_di_teks: ["Belum ada resep di teks ini", "No recipe in this text yet"],
  racik_butuh_daftar_bahan_dan: [
    "Racik butuh daftar bahan dan langkah memasak. Tempel teks yang memuat keduanya.",
    "Racik needs a list of ingredients and cooking steps. Paste text that has both.",
  ],
  belum_ada_resep_di_foto: ["Belum ada resep di foto ini", "No recipe in this photo yet"],
  bahan_dan_langkahnya_belum_terbaca: [
    "Bahan dan langkahnya belum terbaca. Coba foto yang lebih terang dan dekat, atau beberapa foto sekaligus.",
    "The ingredients and steps couldn't be read. Try a brighter, closer photo, or several photos at once.",
  ],
  tambah_resep_sedang_istirahat: ["Tambah Resep sedang istirahat", "Add Recipe is taking a break"],
  import_sedang_istirahat_sebentar_resep: [
    "Import sedang istirahat sebentar. Resep yang sudah tersimpan tetap bisa dibuka. Coba lagi nanti, atau tulis resepnya sendiri.",
    "Importing is paused for a little while. Saved recipes still open. Try again later, or write the recipe yourself.",
  ],
  kamu_sudah_memakai_semua_jatah: [
    "Kamu sudah memakai semua jatah Tambah Resep bulan ini. Resep yang sudah tersimpan tetap bisa dimasak, dan kamu tetap bisa menulis resep sendiri.",
    "You've used all of this month's Add Recipe allowance. You can still cook saved recipes and write your own.",
  ],
  pelan_pelan_dulu_ya: ["Pelan-pelan dulu, ya", "Slow down a little"],
  terlalu_banyak_permintaan_dalam_waktu: [
    "Terlalu banyak permintaan dalam waktu singkat. Tunggu beberapa menit, lalu coba lagi.",
    "Too many requests in a short time. Wait a few minutes, then try again.",
  ],
  racik_sedang_ramai: ["Racik sedang ramai", "Racik is busy right now"],
  coba_lagi_sebentar_lagi_resep: [
    "Coba lagi sebentar lagi. Resep yang sudah tersimpan tetap bisa dibuka.",
    "Try again in a moment. Saved recipes still open.",
  ],
  prosesnya_terlalu_lama: ["Prosesnya terlalu lama", "This is taking too long"],
  racik_belum_selesai_menyusun_resepnya: ["Coba lagi ya.", "Please try again."],
  impor_lagi_gangguan: ["Impor lagi gangguan", "Import is having trouble"],
  coba_lagi_nanti_ya: [
    "Coba lagi nanti ya. Resep yang sudah tersimpan tetap bisa dibuka.",
    "Please try again later. Saved recipes still open.",
  ],
  bisa_dicoba_lagi_beberapa_menit: [
    "Bisa dicoba lagi dalam beberapa menit.",
    "You can try again in a few minutes.",
  ],
  coba_link_lain: ["Coba link lain", "Try another link"],
  biasanya_30_60_detik: [
    "Biasanya 30–60 detik. Kalau videonya perlu didengarkan, bisa sampai 1½ menit.",
    "Usually 30–60 seconds. Up to 1½ minutes if the video needs listening to.",
  ],
  step_ambil_video: ["Mengambil video…", "Fetching the video…"],
  step_baca_keterangan: ["Membaca keterangan…", "Reading the caption…"],
  step_baca_takaran: ["Membaca takaran…", "Reading the amounts…"],
  step_susun_langkah: ["Menyusun langkah…", "Writing the steps…"],
  step_dengarkan: ["Mendengarkan videonya…", "Listening to the video…"],
  step_hampir: ["Hampir selesai…", "Almost done…"],
  step_baca_teks: ["Membaca teksnya…", "Reading the text…"],
  step_baca_foto: ["Membaca fotonya…", "Reading the photo…"],
  step_kirim_berkas: ["Mengirim berkasnya…", "Sending the file…"],
  tidak_ada_internet: ["Tidak ada internet", "No internet"],
  tambah_resep_butuh_internet_resep: [
    "Tambah Resep butuh internet. Resep yang sudah tersimpan tetap bisa dibuka tanpa internet.",
    "Add Recipe needs the internet. Saved recipes still open without it.",
  ],
  link_nya_belum_bisa_dipakai: ["Link-nya belum bisa dipakai", "This link can't be used"],
  gunakan_link_tiktok_instagram_reels: [
    "Gunakan link TikTok, Instagram, atau YouTube.",
    "Use a TikTok, Instagram or YouTube link.",
  ],
  teksnya_masih_kosong: ["Teksnya masih kosong", "The text is empty"],
  tempel_bahan_dan_cara_memasaknya: [
    "Tempel bahan dan cara memasaknya dulu.",
    "Paste the ingredients and method first.",
  ],
  teksnya_terlalu_panjang: ["Teksnya terlalu panjang", "The text is too long"],
  tempel_bagian_bahan_dan_cara: [
    "Tempel bagian bahan dan cara memasaknya saja, paling banyak 20.000 huruf.",
    "Paste just the ingredients and method, up to 20,000 characters.",
  ],
  fotonya_belum_terkirim: ["Fotonya belum terkirim", "The photo wasn't sent"],
  pilih_atau_ambil_foto_resepnya: [
    "Pilih atau ambil foto resepnya dulu.",
    "Pick or take a photo of the recipe first.",
  ],
  berkasnya_belum_terkirim: ["Berkasnya belum terkirim", "The file wasn't sent"],
  pilih_video_atau_rekaman_suaranya: [
    "Pilih video atau rekaman suaranya dulu.",
    "Pick the video or voice recording first.",
  ],
  fotonya_terlalu_besar: ["Fotonya terlalu besar", "The photo is too large"],
  coba_foto_lain_atau_kirim: [
    "Coba foto lain, atau kirim lebih sedikit foto sekaligus.",
    "Try another photo, or send fewer at once.",
  ],
  videonya_terlalu_besar: ["Videonya terlalu besar", "The video is too large"],
  paling_besar_14_mb_pakai: [
    "Paling besar 14 MB. Pakai video yang lebih pendek atau rekaman suaranya saja, atau tempel teks resepnya.",
    "Up to 14 MB. Use a shorter video or just the audio, or paste the recipe text.",
  ],
  berkas_ini_bukan_foto: ["Berkas ini bukan foto", "This file isn't a photo"],
  pilih_foto_resep_jpg_atau: [
    "Pilih foto resep (JPG atau PNG).",
    "Pick a recipe photo (JPG or PNG).",
  ],
  berkas_ini_bukan_video: ["Berkas ini bukan video", "This file isn't a video"],
  pilih_video_atau_rekaman_suara: [
    "Pilih video atau rekaman suara.",
    "Pick a video or voice recording.",
  ],
  fotonya_kebanyakan: ["Fotonya kebanyakan", "Too many photos"],
  paling_banyak_4_foto_sekaligus: ["Paling banyak 4 foto sekaligus.", "Up to 4 photos at once."],
  foto_ini_belum_bisa_dibaca: ["Foto ini belum bisa dibaca", "This photo can't be read"],
  coba_foto_lain: ["Coba foto lain.", "Try another photo."],
  suaranya_tidak_terbaca: ["Suaranya tidak terbaca", "The audio can't be read"],
  suara_di_berkas_itu_tidak: [
    "Suara di berkas itu tidak terbaca. Coba berkas lain, atau tempel teks resepnya.",
    "The audio in that file can't be read. Try another file, or paste the recipe text.",
  ],
  tambah_resep_belum_tersambung: [
    "Tambah Resep belum tersambung",
    "Add Recipe isn't connected yet",
  ],
  coba_lagi_nanti_resep_yang: [
    "Coba lagi nanti. Resep yang sudah tersimpan tetap bisa dibuka.",
    "Try again later. Saved recipes still open.",
  ],
  resep_belum_bisa_disusun_dari: [
    "Resep belum bisa disusun dari {noun}",
    "Couldn't make a recipe from {noun}",
  ],
  coba_lagi_sebentar_lagi: ["Coba lagi sebentar lagi.", "Try again in a moment."],
  auth_provider_failed: [
    "Masuk dengan {provider} belum berhasil. Coba lagi.",
    "Signing in with {provider} didn't work. Try again.",
  ],
  err_no_internet: [
    "Tidak ada internet. Sambungkan dulu, lalu coba lagi.",
    "No internet. Connect first, then try again.",
  ],
  err_cant_connect: [
    "Racik belum bisa tersambung. Periksa internet lalu coba lagi.",
    "Racik can't connect yet. Check the internet and try again.",
  ],
  err_wait_minute: [
    "Tunggu satu menit sebelum minta kode lagi.",
    "Wait a minute before asking for another code.",
  ],
  err_too_many_tries: [
    "Terlalu banyak percobaan. Tunggu sebentar lalu coba lagi.",
    "Too many tries. Wait a moment and try again.",
  ],
  err_link_expired: [
    "Tautan masuknya sudah kedaluwarsa atau sudah dipakai. Minta kode baru di bawah.",
    "The sign-in link has expired or was already used. Ask for a new code below.",
  ],
  err_code_expired: [
    "Kodenya sudah kedaluwarsa. Minta kode baru.",
    "The code has expired. Ask for a new one.",
  ],
  err_signup_closed: [
    "Pendaftaran sedang ditutup untuk email ini.",
    "Sign-up is closed for this email right now.",
  ],
  err_bad_email: [
    "Alamat emailnya belum benar. Periksa lalu coba lagi.",
    "That email address doesn't look right. Check it and try again.",
  ],
  err_code_mismatch: [
    "Kodenya tidak cocok. Periksa lalu coba lagi.",
    "The code doesn't match. Check it and try again.",
  ],
  err_link_unusable: [
    "Tautan masuknya tidak bisa dipakai. Minta kode baru di bawah.",
    "The sign-in link can't be used. Ask for a new code below.",
  ],
  err_code_not_sent: [
    "Kodenya belum terkirim. Coba lagi sebentar lagi.",
    "The code wasn't sent. Try again in a moment.",
  ],
  err_signin_failed: ["Belum berhasil masuk. Coba lagi.", "Couldn't sign in. Try again."],
  password_label: ["Kata sandi", "Password"],
  password_signin: ["Masuk dengan kata sandi", "Sign in with password"],
  err_password_wrong: ["Email atau kata sandi salah.", "Wrong email or password."],
  err_signin_cancelled: [
    "Masuknya dibatalkan. Coba lagi kalau mau.",
    "Sign-in was cancelled. Try again if you like.",
  ],
  err_sms_not_sent: [
    "Kodenya tidak terkirim. Periksa nomornya lalu coba lagi.",
    "The code wasn't sent. Check the number and try again.",
  ],
  err_not_signed_in: ["Kamu belum masuk.", "You're not signed in."],
  err_profile_not_saved: [
    "Profilnya belum tersimpan. Coba lagi.",
    "Your profile wasn't saved. Try again.",
  ],
  err_signin_to_delete: [
    "Masuk dulu ke akunmu untuk menghapusnya.",
    "Sign in to your account first to delete it.",
  ],
  err_photos_not_deleted: [
    "Foto-fotomu belum bisa dihapus. Periksa internet lalu coba lagi.",
    "Your photos couldn't be deleted. Check the internet and try again.",
  ],
  err_account_not_deleted: [
    "Akunmu belum terhapus. Periksa internet lalu coba lagi.",
    "Your account wasn't deleted. Check the internet and try again.",
  ],
  err_handle_format: [
    "Nama pengguna 3–24 huruf kecil, angka, titik atau garis bawah. Tanpa spasi.",
    "Usernames are 3–24 lowercase letters, numbers, dots or underscores. No spaces.",
  ],
  err_display_name: [
    "Nama tampilan 2–40 huruf, atau kosongkan saja.",
    "Display names are 2–40 characters, or leave it empty.",
  ],
  err_handle_taken: [
    "@{h} sudah dipakai orang lain. Coba yang lain.",
    "@{h} is already taken. Try another.",
  ],
  err_handle_blocked: [
    "Nama pengguna itu tidak bisa dipakai. Coba yang lain.",
    "That username can't be used. Try another.",
  ],
  err_handle_server: [
    "Server Racik belum siap untuk nama pengguna. Coba lagi nanti.",
    "Racik's server isn't ready for usernames yet. Try again later.",
  ],
  err_handle_not_saved: [
    "Nama penggunanya belum tersimpan. Coba lagi.",
    "The username wasn't saved. Try again.",
  ],
  v_title_short: [
    "Beri nama resepnya, minimal 3 huruf.",
    "Give the recipe a name, at least 3 characters.",
  ],
  v_title_long: [
    "Nama resepnya terlalu panjang. Cukup 80 huruf.",
    "The recipe name is too long. 80 characters is enough.",
  ],
  v_serv: [
    "Tulis untuk berapa porsi resep ini, antara 1 dan 20.",
    "Say how many portions this recipe makes, between 1 and 20.",
  ],
  v_no_ings: [
    "Tulis bahan-bahannya, satu bahan per baris.",
    "Write the ingredients, one per line.",
  ],
  v_no_steps: [
    "Tulis cara memasaknya, satu langkah per kotak.",
    "Write the method, one step per box.",
  ],
  v_no_amount: [
    '{name} belum ada takarannya. Tulis misalnya "250 gram {lower}" atau "2 buah". Hanya bumbu seperti garam dan gula yang boleh "secukupnya".',
    '{name} has no amount yet. Write for example "250 gram {lower}" or "2 buah". Only seasonings like salt and sugar can be "secukupnya".',
  ],
  v_duplicate: [
    '{name} ditulis dua kali. Gabungkan jadi satu baris, lalu tulis kegunaannya di keterangan (misalnya "sebagian untuk bumbu").',
    '{name} is listed twice. Merge it into one line and note what it\'s for (for example "sebagian untuk bumbu").',
  ],
  v_unknown_ing: [
    'Racik belum kenal "{raw}", jadi takarannya tidak ikut berubah saat porsinya diubah. Coba nama yang lebih umum, misalnya "daun jeruk" atau "cabai merah".',
    'Racik doesn\'t know "{raw}" yet, so its amount won\'t change with the portions. Try a more common name, like "daun jeruk" or "cabai merah".',
  ],
  v_step_missing_ing: [
    "Langkah {n} menyebut {lower}, tapi belum ada di daftar bahan. Tambahkan beserta takarannya.",
    "Step {n} mentions {lower}, but it isn't in the ingredient list. Add it with an amount.",
  ],
  v_ing_unused: [
    "{name} ada di daftar bahan, tapi tidak disebut di langkah mana pun. Sebutkan kapan dimasukkan.",
    "{name} is in the ingredient list but isn't mentioned in any step. Say when it goes in.",
  ],
  v_few_steps: [
    "Langkahnya baru sedikit. Orang yang belum pernah memasak ini perlu tahu urutannya, jadi pecah jadi beberapa langkah kecil.",
    "There are only a few steps. Someone cooking this for the first time needs the order, so split it into smaller steps.",
  ],
  v_time_mismatch: [
    "Waktu di langkah-langkahnya sekitar {total} menit, tapi waktu masaknya ditulis {time} menit. Samakan supaya orang bisa merencanakan.",
    "The steps add up to about {total} minutes, but the cooking time says {time} minutes. Make them match so people can plan.",
  ],
  export_note: [
    "Salinan data Racik milikmu: yang tersimpan di HP ini dan, kalau kamu masuk, yang tersimpan di akunmu.",
    "A copy of your Racik data: what's on this phone and, if you're signed in, what's in your account.",
  ],
  fmt_min: ["{minutes} mnt", "{minutes} min"],
  fmt_h: ["{h} jam", "{h} hr"],
  fmt_h_min: ["{h} jam {m} mnt", "{h} hr {m} min"],
  fmt_sec: ["{seconds} detik", "{seconds} sec"],
  fmt_minutes: ["{m} menit", "{m} minutes"],
  fmt_h_minutes: ["{h} jam {rest} menit", "{h} hr {rest} minutes"],
  halal_label_haram: ["tidak halal", "not halal"],
  halal_label_check: ["perlu dicek", "needs checking"],
  halal_label_ok: ["bahan halal", "halal ingredients"],
  halal_row_haram: ["Ada bahan yang tidak halal: {names}.", "Has non-halal ingredients: {names}."],
  halal_row_check: [
    "Perlu dicek: {names}. Bahan olahan ini bisa mengandung daging, lemak, gelatin, atau alkohol yang tidak halal, tergantung merek — pilih yang ada logo halalnya.",
    "Needs checking: {names}. These processed ingredients can contain non-halal meat, fat, gelatin or alcohol depending on the brand — choose ones with a halal logo.",
  ],
  halal_row_meat: [
    "{names}: beli dari penjual yang menyembelih secara halal. Cara penyembelihan tidak terlihat dari daftar bahan.",
    "{names}: buy from a seller who slaughters the halal way. How it was slaughtered can't be seen from the ingredient list.",
  ],
  halal_row_none: [
    "Tidak ada bahan yang Racik tandai perlu dicek.",
    "Racik didn't flag any ingredient to check.",
  ],
  halal_row_kitchen: [
    "Kebersihan dapur dan alat masak tidak bisa Racik pastikan.",
    "Racik can't vouch for kitchen and utensil cleanliness.",
  ],
  measures_gram_detail: [
    "Bahan ditulis dalam gram atau ml bila beratnya diketahui.",
    "Ingredients in grams or ml when the weight is known.",
  ],
  measures_home_detail: [
    "Bahan ditulis dalam sendok, gelas, siung, dan ukuran dapur lain.",
    "Ingredients in spoons, glasses, cloves and other kitchen measures.",
  ],
  negara_auto: ["Otomatis", "Automatic"],
  source_original: ["sumber asli", "original source"],
  jump_bahan: ["Bahan ({ings})", "Ingredients ({ings})"],
  jump_langkah: ["Langkah ({steps})", "Steps ({steps})"],
  report_thanks: [
    "Terima kasih. Laporanmu sudah kami terima.",
    "Thank you. We've received your report.",
  ],
  halal_chip_haram: ["Mengandung nonhalal", "Contains non-halal"],
  halal_chip_meat: ["Cek sembelihan", "Check the slaughter"],
  halal_chip_check: ["Perlu cek bahan", "Check ingredients"],
  acct_local_count: [
    "{count} resep tersimpan di HP ini saja. Masuk supaya tidak hilang kalau ganti HP.",
    "{count} recipes are saved on this phone only. Sign in so they aren't lost if you change phones.",
  ],
  acct_local_none: [
    "Masuk gratis supaya resep yang kamu simpan tidak hilang kalau ganti HP.",
    "Sign in for free so your saved recipes aren't lost if you change phones.",
  ],
  acct_syncing: ["Menyimpan ke akun…", "Saving to your account…"],
  acct_off: [
    "Resep di HP ini belum digabung ke akunmu. Buka lagi Racik untuk memilih.",
    "Recipes on this phone aren't added to your account yet. Open Racik again to choose.",
  ],
  acct_error: [
    "Belum tersambung. Perubahan disimpan di HP dulu dan dikirim ke akun saat ada internet.",
    "Not connected. Changes are kept on the phone and sent to your account when there's internet.",
  ],
  acct_ok: [
    "Resep, rencana belanja, dan catatan masakmu tersimpan di akun.",
    "Your recipes, shopping plan and cooking notes are saved in your account.",
  ],
  acct_signed_out: [
    "Kamu sudah keluar. Resepmu tetap aman di akun.",
    "You're signed out. Your recipes are safe in your account.",
  ],
  share_card_failed: [
    "Kartunya belum bisa dibuat. Coba lagi.",
    "The card couldn't be made. Try again.",
  ],
  share_text: [
    "{title}, takarannya jelas di Racik: {url}",
    "{title}, with clear amounts on Racik: {url}",
  ],
  share_saved: [
    "Gambar tersimpan. Unggah dari galeri ke Story atau Status.",
    "Image saved. Upload it from your gallery to Story or Status.",
  ],
  share_saved_copied: [
    "Gambar tersimpan dan tautannya sudah disalin. Tempel di keterangan postinganmu.",
    "Image saved and the link copied. Paste it into your post's caption.",
  ],
  share_copied: ["Tautan disalin.", "Link copied."],
  card_recipe_by: ["Resep {who}", "Recipe by {who}"],
  card_cooked_by: ["dimasak oleh {me}", "cooked by {me}"],
  card_cooked_with: ["dimasak dengan Racik", "cooked with Racik"],
  card_from_video: ["Resep dari video", "Recipe from a video"],
  card_cooked_by_cap: ["Dimasak oleh {me}", "Cooked by {me}"],
  card_cooked_with_cap: ["Dimasak dengan Racik", "Cooked with Racik"],
  stat_cook_time: ["waktu masak", "cooking time"],
  stat_steps: ["langkah", "steps"],
  stat_protein: ["protein/porsi", "protein/portion"],
  import_duplicate: [
    "Resep dari link ini sudah ada di Koleksi.",
    "The recipe from this link is already in your Collection.",
  ],
  import_working: ["Sedang meracik resepmu", "Mixing your recipe"],
  photo_unreadable_retake: [
    "Foto ini belum bisa dibaca. Coba foto lain, atau ambil foto baru.",
    "This photo can't be read. Try another, or take a new one.",
  ],
  err_link_not_ready: [
    "Tautan masuknya belum bisa dipakai. Minta kode baru di bawah.",
    "The sign-in link can't be used yet. Ask for a new code below.",
  ],
  tulis_offline: [
    "Racik belum tersambung ke server, jadi resepnya belum bisa diterbitkan. Drafnya aman di HP ini.",
    "Racik isn't connected to the server, so the recipe can't be published yet. The draft is safe on this phone.",
  ],
  tulis_err_saved: ["{err} Drafnya sudah tersimpan.", "{err} The draft is saved."],
  tulis_fix_first: [
    "Ada yang perlu dilengkapi dulu. Lihat tanda merah di daftar bahan dan langkah.",
    "Some things need filling in first. Look for the red marks in the ingredients and steps.",
  ],
  photo_unreadable: [
    "Foto ini belum bisa dibaca. Coba foto lain.",
    "This photo can't be read. Try another one.",
  ],
  draft_saved: ["Draf tersimpan di HP ini.", "Draft saved on this phone."],
  draft_storage_full: [
    "Penyimpanan HP penuh. Fotonya tidak ikut tersimpan.",
    "Phone storage is full. The photo wasn't saved.",
  ],
  no_amount_yet: ["belum ada takaran", "no amount yet"],
  resep_racik: ["Resep Racik", "Racik recipe"],
  cooked_by_handle: ["dimasak oleh @{handle}", "cooked by @{handle}"],
  recipe_by_handle: ["Resep @{handle}", "Recipe by @{handle}"],
  today_suffix: [" (hari ini)", " (today)"],
  wa_at_home: ["\n\nSudah ada di rumah: {names}", "\n\nAlready at home: {names}"],
  plus_to_taste: [" (+ secukupnya)", " (+ to taste)"],
  wa_buy: [" — beli: {buy}", " — buy: {buy}"],
  leave: ["Keluar", "Leave"],
  slot_phrase_sarapan: ["untuk sarapan", "for breakfast"],
  slot_phrase_makan_siang: ["siang ini", "for lunch"],
  slot_phrase_makan_malam: ["malam ini", "for dinner"],
  slot_phrase_camilan: ["buat camilan", "for a snack"],
  kat_barat_1: ["Sup, Stew & Chili", "Soups, stews & chili"],
  kat_barat_2: ["Pasta", "Pasta"],
  kat_barat_3: ["Sandwich, Wrap & Pizza", "Sandwiches, wraps & pizza"],
  kat_barat_4: ["Sarapan", "Breakfast"],
  kat_barat_5: ["Ayam & kalkun", "Chicken & turkey"],
  kat_barat_6: ["Daging sapi", "Beef"],
  kat_barat_7: ["Ikan", "Fish"],
  kat_barat_8: ["Salad", "Salads"],
  kat_barat_9: ["Kue & Camilan", "Bakes & snacks"],
  method_goreng: ["Goreng", "Fried"],
  method_tumis: ["Tumis", "Stir-fried"],
  method_kukus: ["Kukus", "Steamed"],
  method_rebus: ["Rebus", "Boiled"],
  method_bakar: ["Bakar", "Grilled"],
  shelf_cepat: ["Cepat & gampang", "Quick & easy"],
  shelf_bahan: ["Bahan utama", "Main ingredient"],
  shelf_masak: ["Cara masak", "Cooking method"],
  shelf_protein: ["Protein tinggi", "High protein"],
  shelf_pilihan: ["Pilihan makan", "Dietary choices"],
  shelf_daerah: ["Daerah", "Regions"],
  shelf_barat: ["Masakan Barat", "Western dishes"],
  shelf_filipina: ["Masakan Filipina", "Filipino dishes"],
  kat_ph_1: ["Daging & unggas", "Meat & poultry"],
  kat_ph_2: ["Ikan & seafood", "Fish & seafood"],
  kat_ph_3: ["Sup & rebusan", "Soups & stews"],
  kat_ph_4: ["Sayur", "Vegetables"],
  kat_ph_5: ["Pansit & mi", "Pancit & noodles"],
  kat_ph_6: ["Nasi & bubur", "Rice & porridge"],
  kat_ph_7: ["Gorengan & jajanan", "Fried snacks & street food"],
  kat_ph_8: ["Panghimagas (pencuci mulut)", "Desserts (panghimagas)"],
  kat_ph_9: ["Roti & kue kering", "Breads & baked goods"],
  kat_ph_10: ["Acar & sambal", "Pickles & condiments"],
  diet_high_protein: ["Protein tinggi", "High protein"],
  diet_vegetarian: ["Vegetarian", "Vegetarian"],
  diet_vegan: ["Vegan", "Vegan"],
  diet_veg_forward: ["Banyak sayur", "Lots of vegetables"],
  diet_no_santan: ["Tanpa santan", "No coconut milk"],
  halal_footnote: [
    "Racik bukan lembaga sertifikasi halal. Keterangan ini hanya membaca daftar bahan resep — untuk bahan kemasan seperti kecap atau saus, tetap cek logo halal di kemasannya.",
    "Racik is not a halal certification body. This note only reads the recipe's ingredient list — for packaged ingredients like soy sauce or other sauces, still check for a halal logo on the pack.",
  ],
  noun_link: ["link ini", "this link"],
  noun_suara: ["video ini", "this video"],
  noun_berkas: ["berkas ini", "this file"],
  noun_teks: ["teks ini", "this text"],
  noun_foto: ["foto ini", "this photo"],
  status_draft: ["Draf", "Draft"],
  status_live: ["Terbit", "Published"],
  status_hidden: ["Disembunyikan moderator", "Hidden by a moderator"],
  status_removed: ["Dihapus moderator", "Removed by a moderator"],
  status_local: ["Draf di HP ini", "Draft on this phone"],
  report_reason_1: ["Bukan resep", "Not a recipe"],
  report_reason_2: ["Isinya menyinggung atau kasar", "Offensive or abusive"],
  report_reason_3: ["Menyalin resep orang lain", "Copies someone else's recipe"],
  report_reason_4: ["Lainnya", "Something else"],
  prio_kurang_30_menit: ["Cepat dimasak", "Quick to cook"],
  prio_gampang: ["Mudah diikuti", "Easy to follow"],
  prio_protein_tinggi: ["Protein tinggi", "High protein"],
  prio_anak_suka: ["Anak suka", "Kids like it"],
  prio_sekali_masak_banyak: ["Sekali masak banyak", "Cook once, eat a lot"],
  protein_pick_ayam: ["Ayam", "Chicken"],
  protein_pick_ikan: ["Ikan & udang", "Fish & prawns"],
  protein_pick_telur: ["Telur", "Eggs"],
  protein_pick_tahu_tempe: ["Tahu & tempe", "Tofu & tempeh"],
  protein_pick_daging: ["Daging", "Meat"],
  nutr_carb_cap: ["Karbo", "Carbs"],
  nutr_fiber_cap: ["Serat", "Fibre"],
  day_mon: ["Senin", "Monday"],
  day_tue: ["Selasa", "Tuesday"],
  day_wed: ["Rabu", "Wednesday"],
  day_thu: ["Kamis", "Thursday"],
  day_fri: ["Jumat", "Friday"],
  day_sat: ["Sabtu", "Saturday"],
  day_sun: ["Minggu", "Sunday"],
  group_protein: ["Daging, ikan, tahu & telur", "Meat, fish, tofu & eggs"],
  group_veg: ["Sayur & buah", "Vegetables & fruit"],
  group_spice: ["Bumbu segar", "Fresh aromatics"],
  group_pantry: ["Sembako & lainnya", "Pantry & more"],
  group_other: ["Lain-lain", "Other"],
  wa_header: ["Daftar belanja Racik\nUntuk: {titles}", "Racik shopping list\nFor: {titles}"],
  nutr_kcal: ["kkal", "kcal"],
  nutr_protein: ["protein", "protein"],
  nutr_carb: ["karbo", "carbs"],
  nutr_fat: ["lemak", "fat"],
  nutr_fiber: ["serat", "fibre"],
  nutr_note_protein: [
    "Dari berat rata-rata bahan, bukan hasil uji lab. Dipakai untuk menjawab satu hal: masakan ini mengenyangkan atau belum.",
    "From average ingredient weights, not a lab test. It answers one thing: is this dish filling or not.",
  ],
  nutr_note_carb: [
    "Nasi, tepung, gula, dan umbi paling banyak menyumbang. Bukan hasil uji lab.",
    "Rice, flour, sugar and tubers add the most. Not a lab test.",
  ],
  nutr_note_fat: [
    "Minyak, santan, kelapa, dan daging berlemak paling banyak menyumbang. Minyak yang tertinggal di wajan ikut terhitung, jadi angka aslinya bisa lebih rendah.",
    "Oil, coconut milk, coconut and fatty meat add the most. Oil left in the pan is counted too, so the real number may be lower.",
  ],
  nutr_note_fiber: [
    "Dari sayur, kacang, dan buah di resep. Bahan yang belum ada di daftar Racik tidak ikut dihitung, jadi serat aslinya bisa lebih tinggi.",
    "From the vegetables, beans and fruit in the recipe. Ingredients Racik doesn't know yet aren't counted, so the real fibre may be higher.",
  ],
  fmt_kcal: ["{n} kkal", "{n} kcal"],
  pick_recipe_photo: ["Pilih foto resep", "Pick a recipe photo"],
  negara_detail: [
    "Mengubah nama takaran (sendok, cawan, tasa), nama bahan setempat, dan pembulatan daftar belanja.",
    "Changes measure names (spoons, cawan, tasa), local ingredient names and how the shopping list rounds.",
  ],
  negara_detected: ["Terdeteksi dari koneksi: {name}.", "Detected from your connection: {name}."],
  negara_chosen: ["Dipilih: {name}.", "Chosen: {name}."],
  country_ID: ["Indonesia", "Indonesia"],
  country_MY: ["Malaysia", "Malaysia"],
  country_PH: ["Filipina", "Philippines"],
  language_hint: ["Resep tetap dalam Bahasa Indonesia.", "Recipes stay in Bahasa Indonesia."],
  step_n_of: ["Langkah {n} dari {total}", "Step {n} of {total}"],
  step_n: ["Langkah {n}", "Step {n}"],
  coverage_line: [
    "Dihitung dari {counted} dari {total} bahan yang ada takarannya.",
    "Counted from {counted} of {total} ingredients with an amount.",
  ],
  plan_count_line: [
    "{n} dari {max} resep minggu ini. Daftar belanja dibuat otomatis dari bahan yang dibutuhkan.",
    "{n} of {max} recipes this week. The shopping list is built automatically from the ingredients you need.",
  ],
  diff_gampang: ["gampang", "easy"],
  diff_sedang: ["sedang", "medium"],
  diff_agak_ribet: ["agak ribet", "a bit involved"],
  quota_left: ["Sisa {left} dari {limit} bulan ini", "{left} of {limit} left this month"],
  n_steps: ["{n} langkah", "{n} steps"],
  n_portions: ["{n} porsi", "{n} portions"],
} as const;

export type Key = keyof typeof DICT;

/** Off for launch — see the note at the top. */
export const ENGLISH_ENABLED = true;

export function effectiveLang(saved: string | undefined): Lang {
  return ENGLISH_ENABLED && saved === "en" ? "en" : "id";
}

export function translate(lang: Lang, key: Key, vars?: Record<string, string | number>): string {
  const pair = DICT[key];
  let out: string = lang === "en" ? pair[1] : pair[0];
  if (vars) for (const [k, v] of Object.entries(vars)) out = out.split(`{${k}}`).join(String(v));
  return out;
}

/**
 * The interface language for this render. RacikProvider sets it from saved
 * state before its children render, and the app tree is keyed by language
 * (see __root.tsx), so a switch re-renders every screen. That lets t() be a
 * plain function: usable in any component, helper or getter without a hook.
 */
let current: Lang = "id";
export function setCurrentLang(lang: Lang) {
  current = lang;
}
export function currentLang(): Lang {
  return current;
}

/** "gampang" → "easy": a recipe's difficulty word in the interface language. */
export function diffLabel(diff: string): string {
  const key = `diff_${diff.replace(/ /g, "_")}`;
  return key in DICT ? t(key as Key) : diff;
}

/** `t("tab_home")`, `t("for_people", { n: 4 })` */
export function t(key: Key, vars?: Record<string, string | number>): string {
  return translate(current, key, vars);
}

/**
 * Kept for older call sites. The app tree is keyed by language (__root.tsx),
 * so reading the current language here is always up to date.
 */
export function useT() {
  return t;
}

export function useLang(): Lang {
  return current;
}
